"""Run: python -m unittest test_engine -v   (no network needed)"""
import glob, inspect, os, random, re, sqlite3, tempfile, threading, time, unittest
from datetime import datetime
from unittest import mock

import requests

import engine as E


def resp(status=200, payload=None):
    m = mock.Mock(status_code=status)
    m.json.return_value = payload if payload is not None else {}
    return m


BINLIST_OK = {"scheme": "visa", "type": "debit", "brand": "Visa Infinite", "prepaid": False,
              "number": {"luhn": True},
              "country": {"name": "Italy", "alpha2": "IT", "alpha3": "ITA", "currency": "EUR"},
              "bank": {"name": "Revolut Bank UAB", "url": "revolut.com", "phone": "+123"}}
HANDY_OK = {"Status": "SUCCESS", "Scheme": "MASTERCARD", "Type": "CREDIT", "Issuer": "COMMONWEALTH BANK",
            "CardTier": "PLATINUM MASTERCARD", "Luhn": True,
            "Country": {"A2": "AU", "A3": "AUS", "N3": "036", "ISD": "61", "Name": "Australia", "Cont": "Oceania"}}
JP = {"scheme": "mastercard", "type": "credit", "brand": "Gold",
      "country": {"name": "Japan", "alpha2": "JP", "alpha3": "JPN", "currency": "JPY"},
      "bank": {"name": "Mitsubishi UFJ Nicos Co, Ltd."}}


def router(**by_host):
    """Fake network: maps 'binlist.io' / 'handyapi' / 'binlist.net' to a response, an exception,
    or a callable. Records calls."""
    calls = []

    def fake(url, headers=None, timeout=None, stream=False):
        calls.append((url, headers or {}))
        for host, out in by_host.items():
            if host in url:
                if isinstance(out, Exception):
                    raise out
                if inspect.isfunction(out):
                    return out()
                return out
        raise requests.ConnectionError("unmapped " + url)
    fake.calls = calls
    return fake


def wait_for(cond, timeout=3.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.01)
    return False


class Helpers(unittest.TestCase):
    def test_extract_queries_keeps_up_to_eight_digits(self):
        self.assertEqual(E.extract_queries("424242, 510510"), ["424242", "510510"])
        self.assertEqual(E.extract_queries("456288,531416,61100072636"), ["456288", "531416", "61100072"])
        self.assertEqual(E.extract_queries("424242 510510"), ["424242", "510510"])
        self.assertEqual(E.extract_queries("4242 4242 4242 4242"), ["42424242"])
        self.assertEqual(E.extract_queries("12345"), [])
        self.assertEqual(E.extract_queries("424242\u060c 424242"), ["424242"])

    def test_digits_beyond_eight_are_discarded(self):
        self.assertEqual(E.normalize_query("527926229117777"), "52792622")
        self.assertEqual(E.normalize_query("5279 2622 9117"), "52792622")
        self.assertEqual(E.normalize_query("abc"), "")

    def test_detect_scheme(self):
        cases = {"424242": "VISA", "510510": "MASTERCARD", "222100": "MASTERCARD", "378282": "AMEX",
                 "601100": "DISCOVER", "353011": "JCB", "620000": "UNIONPAY", "220000": "MIR",
                 "300000": "DINERS CLUB", "999999": "UNKNOWN"}
        for b, s in cases.items():
            self.assertEqual(E.detect_scheme(b)[0], s, b)

    def test_luhn(self):
        self.assertTrue(E.luhn_steps("79927398713")["valid"])
        self.assertFalse(E.luhn_steps("79927398710")["valid"])
        self.assertEqual(E.luhn_steps("79927398713")["total"], 70)
        self.assertIsNone(E.luhn_steps("7"))
        self.assertFalse(E.luhn_steps("123456")["valid"])

    def test_luhn_batch(self):
        r = E.luhn_batch("79927398713\n79927398710, 7, 123456789012345678901")
        self.assertEqual((r["passed"], r["failed"]), (1, 1))
        self.assertEqual(r["items"][2]["error"], "Too short")
        self.assertEqual(r["items"][3]["error"], "Longer than 19 digits")
        big = E.luhn_batch(",".join(["79927398713"] * 40))
        self.assertEqual(len(big["items"]), 25); self.assertTrue(big["truncated"])
        self.assertEqual(E.mask_number("79927398713"), "79927398713")
        m = E.mask_number("4" * 16)
        self.assertEqual(len(m), 16); self.assertIn("\u2022", m)


class Engine(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "t.db")
        self.eng = E.BinEngine(self.path)
        self.eng.export_dirs = [os.path.join(self.tmp.name, "BIN ATLAS")]

    def tearDown(self):
        self.tmp.cleanup()

    def live(self, q="416598", payload=BINLIST_OK):
        with mock.patch("engine._http_get", router(**{"binlist.io": resp(200, payload)})):
            return self.eng.lookup(q)

    # ---- providers, failover, speed ----------------------------------
    def test_primary_provider_success_and_cache(self):
        fake = router(**{"binlist.io": resp(200, BINLIST_OK)})
        with mock.patch("engine._http_get", fake):
            r = self.eng.lookup("416598")
            self.assertEqual((r["status"], r["bank"], r["type"], r["brand"]), ("live", "REVOLUT BANK UAB", "DEBIT", "VISA INFINITE"))
            self.assertEqual(r["luhn"], "Yes"); self.assertIn("binlist.io: ok", r["trail"])
            n = len(fake.calls)
            self.assertEqual(self.eng.lookup("416598")["status"], "cached")
            self.assertEqual(len(fake.calls), n)

    def test_failover_chain_and_trail(self):
        fake = router(**{"binlist.io": resp(500), "handyapi": resp(200, HANDY_OK), "binlist.net": resp(404)})
        with mock.patch("engine._http_get", fake):
            r = self.eng.lookup("535316")
        self.assertTrue(r["found"]); self.assertEqual(r["source"], "handyapi")
        self.assertEqual((r["continent"], r["dial_code"], r["country_a3"]), ("OCEANIA", "+61", "AUS"))
        self.assertIn("binlist.io: unreachable", r["trail"]); self.assertIn("handyapi: ok", r["trail"])

    def test_slow_first_provider_is_hedged(self):
        def slow():
            time.sleep(0.6); return resp(200, BINLIST_OK)
        fake = router(**{"binlist.io": slow, "handyapi": resp(200, HANDY_OK)})
        with mock.patch("engine._http_get", fake), mock.patch.object(E, "HEDGE_DELAY", 0.05), \
                mock.patch.object(self.eng, "get_setting", side_effect=lambda k, d="": "0" if k == "combine" else ""):
            t0 = time.time(); r = self.eng.lookup("535316"); dt = time.time() - t0
        self.assertEqual(r["source"], "handyapi"); self.assertLess(dt, 0.45)   # did not wait for the slow one

    def test_total_outage_still_returns_something(self):
        with mock.patch("engine._http_get", router()):
            r = self.eng.lookup("408353")
            self.assertTrue(r["found"]); self.assertEqual(r["status"], "sample")
            r2 = self.eng.lookup("457173")
            self.assertFalse(r2["found"]); self.assertEqual(r2["detected_scheme"], "VISA")
            self.assertIn("offline", r2["message"].lower())

    def test_cooldown_skips_failed_providers(self):
        fake = router()
        with mock.patch("engine._http_get", fake):
            self.eng.lookup("457173"); first = len(fake.calls)
            self.eng.lookup("457174"); self.assertEqual(len(fake.calls), first)
            r = self.eng.lookup("457175"); self.assertIn("paused", r["trail"]); self.assertIn("offline", r["message"].lower())

    def test_gap_fill_sync_and_async(self):
        sparse = dict(BINLIST_OK, type=None, brand=None)
        fake = router(**{"binlist.io": resp(200, sparse), "handyapi": resp(200, HANDY_OK)})
        with mock.patch("engine._http_get", fake):
            r = self.eng.lookup("535316")                                   # synchronous fill
        self.assertEqual((r["type"], r["brand"]), ("CREDIT", "PLATINUM MASTERCARD")); self.assertIn("+", r["source"])
        eng2 = E.BinEngine(os.path.join(self.tmp.name, "b.db")); got = []
        with mock.patch("engine._http_get", fake):
            r2 = eng2.lookup("535316", on_update=got.append)                # primary result first...
            self.assertEqual(r2["type"], "N/A")
            self.assertTrue(wait_for(lambda: got))                          # ...fill arrives in background
        self.assertEqual(got[-1]["type"], "CREDIT"); self.assertEqual(got[-1]["status"], "live")

    def test_combine_off_uses_single_source(self):
        self.eng.set_setting("combine", "0")
        fake = router(**{"binlist.io": resp(200, dict(BINLIST_OK, type=None)), "handyapi": resp(200, HANDY_OK)})
        with mock.patch("engine._http_get", fake):
            r = self.eng.lookup("535316")
        self.assertEqual(r["source"], "binlist.io"); self.assertEqual(len(fake.calls), 1)

    def test_instant_local_answer_then_background_upgrade(self):
        got = []
        fake = router(**{"binlist.io": resp(200, dict(BINLIST_OK, scheme="visa"))})
        with mock.patch("engine._http_get", fake):
            r = self.eng.lookup("408353", on_update=got.append)             # bundled sample row
            self.assertTrue(r["found"]); self.assertTrue(r["refreshing"]); self.assertEqual(r["status"], "sample")
            self.assertTrue(wait_for(lambda: got))
        self.assertEqual((got[0]["status"], got[0]["bank"]), ("live", "REVOLUT BANK UAB"))

    def test_background_refresh_offline_keeps_local_data(self):
        got = []
        with mock.patch("engine._http_get", router()):
            self.eng.lookup("408353", on_update=got.append)
            self.assertTrue(wait_for(lambda: got))
        self.assertEqual(got[0]["status"], "sample"); self.assertIn("offline", got[0]["message"].lower())

    def test_null_bank_ratelimit_auth_negative_cache(self):
        self.assertEqual(self.live("457173", dict(BINLIST_OK, bank=None))["bank"], "N/A")
        e2 = E.BinEngine(os.path.join(self.tmp.name, "b.db"))
        with mock.patch("engine._http_get", router(**{"binlist.io": resp(429), "handyapi": resp(429), "binlist.net": resp(429)})):
            self.assertIn("rate limit", e2.lookup("999991")["message"])
        e3 = E.BinEngine(os.path.join(self.tmp.name, "c.db"))
        with mock.patch("engine._http_get", router(**{"binlist.io": resp(401), "handyapi": resp(403), "binlist.net": resp(401)})):
            self.assertIn("key", e3.lookup("999992")["message"].lower())
        # handyapi/binlist.net are now paused (the gap-fill above hit unmapped hosts), so one
        # provider saying "unknown" must NOT be cached as "no data" for 24 hours.
        with mock.patch("engine._http_get", router(**{"binlist.io": resp(404)})):
            self.assertFalse(self.eng.lookup("999990")["found"])
        self.assertFalse(self.eng._recent_miss("999990"))
        e4 = E.BinEngine(os.path.join(self.tmp.name, "n.db"))
        nf = router(**{"binlist.io": resp(404), "handyapi": resp(404), "binlist.net": resp(404)})
        with mock.patch("engine._http_get", nf):
            self.assertFalse(e4.lookup("999999")["found"]); n = len(nf.calls)
            e4.lookup("999999"); self.assertEqual(len(nf.calls), n)      # all providers agreed: cached
        mixed = router(**{"binlist.io": resp(404), "handyapi": resp(500), "binlist.net": resp(500)})
        with mock.patch("engine._http_get", mixed):
            self.eng.lookup("999998")
        self.assertFalse(self.eng._recent_miss("999998"))
        with mock.patch("engine._http_get", router(**{"binlist.io": resp(500), "handyapi": resp(200, {"Status": "DEMO LIMIT"}), "binlist.net": resp(500)})):
            E.BinEngine(os.path.join(self.tmp.name, "d.db")).lookup("999997")

    def test_keys_headers_and_secret_key_refused(self):
        bad = self.eng.set_api_keys(handyapi="HAS-" + "x" * 20, binlistio="bl_test")
        self.assertTrue(bad and "SECRET" in bad[0]); self.assertFalse(self.eng.has_keys())
        self.assertTrue(self.eng.set_api_keys("bad key", ""))
        self.assertEqual(self.eng.set_api_keys("PUB-" + "y" * 20, "bl_" + "z" * 20), [])
        fake = router(**{"binlist.io": resp(500), "handyapi": resp(200, HANDY_OK)})
        with mock.patch("engine._http_get", fake):
            self.eng.lookup("535316")
        hdr = {u.split("//")[1].split("/")[0]: h for u, h in fake.calls}
        self.assertEqual(hdr["binlist.io"].get("X-API-Key"), "bl_" + "z" * 20)
        self.assertEqual(hdr["data.handyapi.com"].get("x-api-key"), "PUB-" + "y" * 20)

    def test_test_providers(self):
        fake = router(**{"binlist.io": resp(200, BINLIST_OK), "handyapi": resp(401), "binlist.net": resp(429)})
        with mock.patch("engine._http_get", fake):
            out = self.eng.test_providers()
        self.assertTrue(out["binlist.io"][0]); self.assertTrue(out["binlist.io"][1].startswith("working"))
        self.assertEqual(out["handyapi"], (False, "key rejected")); self.assertEqual(out["binlist.net"], (False, "rate limit"))

    # ---- searched number, save, notes, history -----------------------
    def test_save_exact_digits_with_note_and_time(self):
        self.live("527926", JP)
        self.assertFalse(self.eng.save_query("000000", "x"))                 # unknown BIN can't be saved
        self.assertTrue(self.eng.save_query("52792622", "  my note  "))
        self.assertTrue(self.eng.save_query("52792699", "second"))           # same BIN, different searched number
        rows = self.eng.saved()
        self.assertEqual(sorted((r["query"], r["bin"], r["note"]) for r in rows),
                         [("52792622", "527926", "my note"), ("52792699", "527926", "second")])
        self.assertTrue(all(re.match(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d", r["saved_at"]) for r in rows))
        rec = self.eng.get_record("52792622")
        self.assertEqual((rec["query"], rec["saved"], rec["note"]), ("52792622", True, "my note"))
        self.assertFalse(self.eng.get_record("527926")["saved"])             # the 6-digit form is a different entry
        self.assertEqual([r["query"] for r in self.eng.saved("my note")], ["52792622"])
        self.assertEqual([r["query"] for r in self.eng.saved("japan")], ["52792699", "52792622"])
        self.eng.save_query("52792622", "edited"); self.assertEqual(self.eng.get_record("52792622")["note"], "edited")
        self.eng.unsave_query("52792622"); self.assertFalse(self.eng.get_record("52792622")["saved"])

    def test_nothing_beyond_eight_digits_is_ever_stored(self):
        self.live("527926", JP)
        self.assertTrue(self.eng.save_query("527926229117", "long"))
        self.assertEqual(self.eng.saved()[0]["query"], "52792622")
        with mock.patch("engine._http_get", router()):
            self.eng.lookup("5279262291177777", allow_network=False)
        dump = " ".join(str(v) for t in ("bins", "saved", "searches", "misses", "settings")
                        for r in self.eng._q(f"SELECT * FROM {t}") for v in r.values())
        self.assertNotIn("527926229", dump)

    def test_history_records_searched_number_and_get_record_is_pure(self):
        self.eng.get_record("408353"); self.assertEqual(self.eng.history(), [])
        self.eng.lookup("40835377", allow_network=False)
        h = self.eng.history(); self.assertEqual((h[0]["query"], h[0]["bin"]), ("40835377", "408353"))
        self.eng.clear_history(); self.assertEqual(self.eng.history(), [])

    def test_migrates_v1_1_database(self):
        old = os.path.join(self.tmp.name, "old.db")
        conn = sqlite3.connect(old)
        conn.execute("CREATE TABLE bins (bin TEXT PRIMARY KEY, scheme TEXT, type TEXT, brand TEXT, bank TEXT, phone TEXT, "
                     "url TEXT, country TEXT, country_code TEXT, currency TEXT, prepaid TEXT, commercial TEXT, source TEXT, "
                     "fetched_at TEXT, looked_up_at TEXT, lookup_count INTEGER DEFAULT 0, favorite INTEGER DEFAULT 0)")
        conn.execute("INSERT INTO bins (bin,scheme,type,bank,country_code,favorite,source,looked_up_at) VALUES "
                     "('416598','VISA','DEBIT','REVOLUT','IT',1,'binlist.net','2026-10-01 10:00:00')")
        conn.commit(); conn.close()
        eng = E.BinEngine(old)
        s = eng.saved(); self.assertEqual([(r["query"], r["bank"]) for r in s], [("416598", "REVOLUT")])
        self.assertEqual(eng.history()[0]["query"], "416598")
        self.assertEqual(E.BinEngine(old).saved_count(), 1)                  # re-opening does not duplicate

    # ---- cascading filters, paging -----------------------------------
    def test_options_cascade_and_paging(self):
        countries = dict(self.eng.options("country", limit=500))
        self.assertEqual(countries["US"], "UNITED STATES"); self.assertIn("SA", countries)
        self.assertEqual([k for k, _ in self.eng.options("country", like="saudi")], ["SA"])
        self.assertEqual([k for k, _ in self.eng.options("country", like="indo")], ["ID"])
        us = [k for k, _ in self.eng.options("scheme", country="US")]
        self.assertEqual(sorted(us), ["AMEX", "MASTERCARD", "VISA"])
        banks_us = [k for k, _ in self.eng.options("bank", country="US", limit=100)]
        self.assertIn("JPMORGAN CHASE BANK, N.A.", banks_us); self.assertNotIn("AL RAJHI BANK", banks_us)
        self.assertEqual([k for k, _ in self.eng.options("bank", country="US", like="chase")], ["JPMORGAN CHASE BANK, N.A."])
        self.assertEqual(self.eng.options("type", country="US", scheme="VISA", bank="JPMORGAN CHASE BANK, N.A."), [("DEBIT", "DEBIT")])
        self.assertEqual(self.eng.options("level", country="US", scheme="VISA", bank="JPMORGAN CHASE BANK, N.A.", type_="DEBIT"),
                         [("CLASSIC", "CLASSIC")])
        p1 = self.eng.options("bank", limit=3); p2 = self.eng.options("bank", limit=3, offset=3)
        self.assertEqual((len(p1), len(p2)), (3, 3)); self.assertFalse({k for k, _ in p1} & {k for k, _ in p2})
        self.assertEqual([r["bin"] for r in self.eng.search_filters(country="US", scheme="VISA", type_="CREDIT")], ["424242"])
        self.assertEqual(self.eng.count_filters(), 7)
        q1, q2 = self.eng.search_filters(limit=3), self.eng.search_filters(limit=3, offset=3)
        self.assertEqual((len(q1), len(q2)), (3, 3)); self.assertFalse({r["bin"] for r in q1} & {r["bin"] for r in q2})

    def test_bank_search_starts_with_for_short_text_and_ranks_prefix_first(self):
        with sqlite3.connect(self.path) as conn:
            conn.executemany("INSERT INTO bins (bin,scheme,type,brand,bank,country,country_code,source) "
                             "VALUES (?,?,?,?,?,?,?,?)", [
                ("900001", "VISA", "DEBIT", "X", "ALPHA BANK", "GREECE", "GR", E.IMPORT_SOURCE),
                ("900002", "VISA", "DEBIT", "X", "ABN AMRO", "NETHERLANDS", "NL", E.IMPORT_SOURCE),
                ("900003", "VISA", "DEBIT", "X", "BANK OF AMERICA", "UNITED STATES", "US", E.IMPORT_SOURCE),
                ("900004", "VISA", "DEBIT", "X", "CHASEFIELD CREDIT UNION", "UNITED STATES", "US", E.IMPORT_SOURCE),
                ("900005", "VISA", "DEBIT", "X", "WELLS FARGO AND CHASE PARTNERS", "UNITED STATES", "US", E.IMPORT_SOURCE)])
        names = lambda like, **kw: [k for k, _ in self.eng.options("bank", like=like, limit=50, **kw)]
        self.assertEqual(names("j"), ["JPMORGAN CHASE BANK, N.A."])                       # "J" -> only names starting with J
        self.assertEqual(names("a"), ["ABN AMRO", "AL RAJHI BANK", "ALPHA BANK", "AMERICAN EXPRESS COMPANY"])
        self.assertNotIn("BANK OF AMERICA", names("a"))                                   # contains "A" but does not start with it
        self.assertEqual(names("ba"), ["BANK OF AMERICA"])                                # 2 letters: still starts-with
        chase = names("chase")                                                            # 3+ letters: contains, starts-with first
        self.assertEqual(chase[0], "CHASEFIELD CREDIT UNION"); self.assertEqual(len(chase), 3)
        self.assertIn("JPMORGAN CHASE BANK, N.A.", chase)
        self.assertEqual(names("a", country="US"), ["AMERICAN EXPRESS COMPANY"])         # inside the chosen country only
        self.assertEqual(names("", country="US", ), sorted(names("", country="US")))      # no text: alphabetical
        self.assertEqual([k for k, _ in self.eng.options("country", like="un")], ["US"])  # countries follow the same rule
        self.assertEqual([k for k, _ in self.eng.options("country", like="states")], ["US"])

    def test_large_database_filters_stay_paged_and_fast(self):
        rows = [(f"{600000 + i:06d}", "VISA", "DEBIT", "CLASSIC", f"BANK {i % 3000:04d}", f"COUNTRY {i % 200:03d}",
                 f"C{i % 200:03d}"[:2] + chr(65 + i % 26), E.IMPORT_SOURCE) for i in range(60000)]
        with sqlite3.connect(self.path) as conn:
            conn.executemany("INSERT OR IGNORE INTO bins (bin,scheme,type,brand,bank,country,country_code,source) "
                             "VALUES (?,?,?,?,?,?,?,?)", rows)
        self.eng._create_bulk_indexes(); self.eng._q("ANALYZE bins")
        t0 = time.time()
        page = self.eng.options("bank", limit=40)                    # the call that used to freeze the app
        self.assertEqual(len(page), 40); self.assertLess(time.time() - t0, 1.0)
        self.assertLessEqual(len(self.eng.options("country", limit=40)), 40)
        self.assertEqual(len(self.eng.options("bank", like="BANK 0123", limit=40)), 1)

    def test_indexes_are_created_and_old_one_removed(self):
        with sqlite3.connect(self.path) as conn:
            conn.execute("CREATE INDEX idx_bins_country ON bins(country_code)")
        E.BinEngine(self.path)
        names = {r["name"] for r in self.eng._q("SELECT name FROM sqlite_master WHERE type='index'")}
        self.assertTrue(set(E.BULK_INDEXES) <= names); self.assertNotIn("idx_bins_country", names)

    # ---- offline database ---------------------------------------------
    CSV = ('BIN,Brand,Type,Category,Issuer,IssuerPhone,IssuerUrl,isoCode2,isoCode3,CountryName\n'
           '010150,PAGOBANCOMAT,DEBIT,,,,,IT,ITA,ITALY\n'
           '011300,"LOCAL BRAND",DEBIT,"PROPRIETARY ATM","BDO UNIBANK, INC.",,,PH,PHL,PHILIPPINES\n'
           '012004,"PRIVATE LABEL",DEBIT,CLASSIC,"TBI\n\nBANK",+911800,https://sbi.co.in,IN,IND,INDIA\n'
           '12345,VISA,DEBIT,X,BAD,,,DK,DNK,DENMARK\n'
           '424242,VISA,DEBIT,X,SHOULD NOT OVERWRITE,,,US,USA,UNITED STATES\n')

    def write_csv(self, text=None):
        p = os.path.join(self.tmp.name, "bins.csv")
        with open(p, "w", encoding="utf-8") as fh: fh.write(text or self.CSV)
        return p

    def test_import_dataset_adds_all_countries(self):
        msgs = []
        r = self.eng.import_csv(self.write_csv(), msgs.append)
        self.assertEqual(r, {"rows": 5, "added": 3})
        codes = [cc for cc, _ in self.eng.options("country", limit=500)]
        self.assertTrue({"IT", "PH", "IN", "US", "SA", "ID"} <= set(codes))
        self.assertEqual(self.eng.get_record("424242")["bank"], "STRIPE TEST BANK")       # not overwritten
        self.assertEqual(self.eng.get_record("011300")["bank"], "BDO UNIBANK, INC.")
        self.assertEqual(self.eng.get_record("011300")["status"], "offline_db")
        names = {r["name"] for r in self.eng._q("SELECT name FROM sqlite_master WHERE type='index'")}
        self.assertTrue(set(E.BULK_INDEXES) <= names)                                      # indexes rebuilt
        bad = os.path.join(self.tmp.name, "bad.csv")
        with open(bad, "w") as fh: fh.write("foo,bar\n1,2\n")
        with self.assertRaises(ValueError): self.eng.import_csv(bad)

    def test_offline_database_row_answers_instantly_and_upgrades(self):
        self.eng.import_csv(self.write_csv()); got = []
        with mock.patch("engine._http_get", router(**{"binlist.io": resp(200, BINLIST_OK)})):
            r = self.eng.lookup("011300", on_update=got.append)
            self.assertEqual((r["status"], r["refreshing"]), ("offline_db", True))
            self.assertTrue(wait_for(lambda: got))
        self.assertEqual(got[0]["status"], "live")

    def test_download_dataset(self):
        class Fake:
            status_code = 200
            def iter_content(self, n): yield E_CSV[:60].encode(); yield E_CSV[60:].encode()
        E_CSV = self.CSV
        with mock.patch("engine._http_get", return_value=Fake()):
            r = self.eng.download_dataset()
        self.assertEqual(r["added"], 3)
        self.assertFalse(any(f.endswith(".part") for f in os.listdir(self.tmp.name)))
        self.assertTrue(self.eng.get_setting("dataset_loaded"))
        with mock.patch("engine._http_get", return_value=mock.Mock(status_code=500)):
            with self.assertRaises(RuntimeError): self.eng.download_dataset()
        with mock.patch("engine._http_get", side_effect=requests.ConnectionError):
            with self.assertRaisesRegex(RuntimeError, "internet"): self.eng.download_dataset()
        self.assertFalse(any(f.endswith(".part") for f in os.listdir(self.tmp.name)))

    # ---- TXT export -----------------------------------------------------
    def test_txt_export_matches_requested_format(self):
        self.live("527926", JP)
        self.live("405542", dict(BINLIST_OK, scheme="visa", type="credit", brand="Classic",
                                 bank={"name": "PT. BANK DBS INDONESIA"}, country={"name": "Indonesia", "alpha2": "ID"}))
        self.live("374355", {"scheme": "amex", "type": "credit", "brand": "Personal",
                             "bank": {"name": "USAA SAVINGS BANK"}, "country": {"name": "United States", "alpha2": "US"}})
        for q, note in (("52792622", "first note"), ("405542", ""), ("37435512", "third note")):
            self.assertTrue(self.eng.save_query(q, note))
        self.eng._q("UPDATE saved SET saved_at='2026-10-16 12:54:10'")
        rows = sorted(self.eng.saved(), key=lambda r: ["52792622", "405542", "37435512"].index(r["query"]))
        txt = self.eng.format_export(rows)
        sep = "-" * 53
        expected = "\n".join([
            sep, "DATE : 16/10/2026", "TIME : 12:54", sep,
            "52792622", "\U0001F517 TYPE \u279C MASTERCARD", "\U0001F3E6 BANK \u279C MITSUBISHI UFJ NICOS CO, LTD.",
            "\U0001F30D COUNTRY \u279C \U0001F1EF\U0001F1F5 JAPAN", "\U0001F4B3 INFO \u279C GOLD - CREDIT - MASTERCARD",
            "\u2139\uFE0F NOTE \u279C first note", sep,
            "405542", "\U0001F517 TYPE \u279C VISA", "\U0001F3E6 BANK \u279C PT. BANK DBS INDONESIA",
            "\U0001F30D COUNTRY \u279C \U0001F1EE\U0001F1E9 INDONESIA", "\U0001F4B3 INFO \u279C CLASSIC - CREDIT - VISA",
            "\u2139\uFE0F NOTE \u279C -", sep,
            "37435512", "\U0001F517 TYPE \u279C AMERICAN EXPRESS", "\U0001F3E6 BANK \u279C USAA SAVINGS BANK",
            "\U0001F30D COUNTRY \u279C \U0001F1FA\U0001F1F8 UNITED STATES",
            "\U0001F4B3 INFO \u279C PERSONAL - CREDIT - AMERICAN EXPRESS", "\u2139\uFE0F NOTE \u279C third note"]) + "\n"
        self.assertEqual(txt, expected)                                   # exact layout, one shared header

    def test_txt_export_new_header_when_time_differs_and_file_is_written(self):
        self.live("527926", JP)
        a = dict(self.eng.get_record("527926"), saved_at="2026-10-16 12:54:00", query="527926", note="a")
        b = dict(a, saved_at="2026-10-17 08:05:00", query="52792622", note="b")
        txt = self.eng.format_export([a, b])
        self.assertEqual(txt.count("DATE : "), 2); self.assertIn("DATE : 17/10/2026\nTIME : 08:05", txt)
        path, name, preferred = self.eng.export_text_file(txt)
        self.assertTrue(name.endswith(".txt") and os.path.exists(path))
        self.assertTrue(preferred); self.assertEqual(os.path.basename(os.path.dirname(path)), "BIN ATLAS")
        with open(path, encoding="utf-8") as fh: self.assertEqual(fh.read(), txt)
        self.assertEqual(self.eng.format_entry(a).splitlines()[0], "527926")


class Finder(unittest.TestCase):
    """BIN Finder: BINs spread over different countries, at most 3 per country."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.eng = E.BinEngine(os.path.join(self.tmp.name, "t.db"))
        rows = ["BIN,Brand,Type,Category,Issuer,isoCode2,isoCode3,CountryName"]
        schemes = ["VISA", "MASTERCARD", "AMERICAN EXPRESS", "JCB"]
        for c in range(40):                                   # 40 countries x 8 BINs
            for i in range(8):
                rows.append(f"{200000 + c * 100 + i:06d},{schemes[(c + i) % 4]},CREDIT,GOLD,BANK {c}-{i},"
                            f"{chr(65 + c // 26)}{chr(65 + c % 26)},XXX,COUNTRY {c:02d}")
        path = os.path.join(self.tmp.name, "f.csv")
        with open(path, "w") as fh: fh.write("\n".join(rows) + "\n")
        self.eng.import_csv(path)

    def tearDown(self):
        self.tmp.cleanup()

    def per_country(self, rows):
        counts = {}
        for r in rows: counts[r["country_code"]] = counts.get(r["country_code"], 0) + 1
        return counts

    def test_count_is_honoured_and_at_most_three_per_country(self):
        for n in (10, 25, 50, 80):
            rows = self.eng.find_bins(None, n)
            self.assertEqual(len(rows), n)
            self.assertEqual(len({r["bin"] for r in rows}), n)                      # no duplicates
            self.assertLessEqual(max(self.per_country(rows).values()), 3)
        rows = self.eng.find_bins(None, 10)
        self.assertEqual(len(self.per_country(rows)), 10)                           # 10 BINs = 10 different countries
        self.assertTrue(all(r["query"] == r["bin"] and len(r["bin"]) == 6 for r in rows))

    def test_scheme_filter_aliases_and_mix(self):
        for s in ("VISA", "JCB", "MASTERCARD"):
            rows = self.eng.find_bins([s], 40)
            self.assertTrue(rows and all(r["scheme"] == s for r in rows), s)
        amex = self.eng.find_bins(["AMEX"], 100)                                    # bundled sample says "AMEX", dataset "AMERICAN EXPRESS"
        self.assertTrue(all(r["scheme"] in ("AMEX", "AMERICAN EXPRESS") for r in amex))
        self.assertEqual({r["scheme"] for r in amex}, {"AMEX", "AMERICAN EXPRESS"})  # one chip finds both spellings
        mix = self.eng.find_bins(None, 90)
        self.assertEqual(len(mix), 90)
        self.assertGreaterEqual(len({r["scheme"] for r in mix}), 3)

    def test_fewer_results_when_not_enough_and_hard_cap(self):
        self.assertEqual(len(self.eng.find_bins(["VISA"], 100)), len(self.eng.find_bins(["VISA"], 100)))
        self.assertLessEqual(len(self.eng.find_bins(None, 100)), 100)
        self.assertEqual(len(self.eng.find_bins(None, 5000)), 100)                  # capped at FINDER_MAX
        self.assertEqual(self.eng.find_bins(["DISCOVER"], 10), [])                  # nothing of that network
        self.assertEqual(len(self.eng.find_bins(["VISA"], 1)), 1)

    def test_single_country_gives_only_that_country(self):
        rows = self.eng.find_bins(None, 10, country="AA")                           # country AA has 8 BINs in the test data
        self.assertEqual(len(rows), 8)                                              # fewer than asked: all it has
        self.assertTrue(all(r["country_code"] == "AA" for r in rows))
        self.assertEqual(len({r["bin"] for r in rows}), 8)                          # no duplicates
        rows = self.eng.find_bins(None, 5, country="AA")
        self.assertEqual(len(rows), 5)                                              # more than 3 allowed for one country
        jcb = self.eng.find_bins(["JCB"], 50, country="AA")
        self.assertTrue(jcb and all(r["scheme"] == "JCB" and r["country_code"] == "AA" for r in jcb))
        self.assertEqual(self.eng.find_bins(["DISCOVER"], 5, country="US"), [])     # no such network there
        self.assertEqual(self.eng.find_bins(None, 5, country="ZZ"), [])             # unknown country
        us = self.eng.find_bins(None, 100, country="US")
        self.assertEqual(sorted(r["bin"] for r in us), sorted({r["bin"] for r in us}))
        self.assertTrue(all(r["country_code"] == "US" for r in us))
        a = [r["bin"] for r in self.eng.find_bins(None, 5, country="AA", rng=random.Random(3))]
        b = [r["bin"] for r in self.eng.find_bins(None, 5, country="AA", rng=random.Random(3))]
        self.assertEqual(sorted(a), sorted(b))                                      # reproducible with a seed

    def test_all_countries_still_spreads_when_country_is_empty(self):
        rows = self.eng.find_bins(None, 10, country="")
        self.assertEqual(len({r["country_code"] for r in rows}), 10)                # unchanged "All" behaviour

    def test_random_but_reproducible_with_a_seed(self):
        a = [r["bin"] for r in self.eng.find_bins(None, 20, rng=random.Random(7))]
        b = [r["bin"] for r in self.eng.find_bins(None, 20, rng=random.Random(7))]
        c = [r["bin"] for r in self.eng.find_bins(None, 20, rng=random.Random(8))]
        self.assertEqual(a, b); self.assertNotEqual(a, c)

    def test_schemes_available_are_canonical(self):
        names = self.eng.schemes_available()
        self.assertEqual(names[:3], ["VISA", "MASTERCARD", "AMEX"])
        self.assertNotIn("AMERICAN EXPRESS", names); self.assertIn("JCB", names)
        self.assertEqual(len(names), len(set(names)))

    def test_delete_one_history_entry_keeps_saved_copy(self):
        self.eng.lookup("424242", allow_network=False); self.eng.lookup("510510", allow_network=False)
        self.eng.save_query("424242", "keep me")
        self.eng.delete_search("424242")
        self.assertEqual([h["query"] for h in self.eng.history()], ["510510"])
        self.assertEqual([s["query"] for s in self.eng.saved()], ["424242"])       # saved copy untouched
        self.eng.unsave_query("424242"); self.eng.delete_search("999999")           # unknown: no error
        self.assertEqual(self.eng.saved(), [])


class ExportFolder(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.eng = E.BinEngine(os.path.join(self.tmp.name, "t.db"))
        blocker = os.path.join(self.tmp.name, "blocked")
        with open(blocker, "w") as fh: fh.write("a file, so nothing can be created under it")
        self.blocked = os.path.join(blocker, "BIN ATLAS")                   # unwritable, like a denied permission

    def tearDown(self):
        self.tmp.cleanup()

    def test_requested_folder_is_the_default_target(self):
        self.assertEqual(E.PUBLIC_EXPORT_DIRS[0], "/storage/emulated/0/BIN ATLAS")
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("BINATLAS_EXPORT_DIRS", None)
            self.assertEqual(E.BinEngine(os.path.join(self.tmp.name, "x.db")).export_dirs[0], "/storage/emulated/0/BIN ATLAS")

    def test_preferred_folder_is_created_and_used(self):
        pref = os.path.join(self.tmp.name, "sdcard", "BIN ATLAS")
        self.eng.export_dirs = [pref, os.path.join(self.tmp.name, "other")]
        folder, preferred = self.eng.export_folder()
        self.assertEqual((folder, preferred), (pref, True)); self.assertTrue(os.path.isdir(pref))
        self.assertEqual(os.listdir(pref), [])                              # the write test leaves nothing behind
        path, name, ok = self.eng.export_text_file("hello\n")
        self.assertTrue(ok and path.startswith(pref)); self.assertEqual(open(path, encoding="utf-8").read(), "hello\n")

    def test_concurrent_checks_never_misreport(self):
        """Regression: the start-up thread and an export share one folder; they must not clash."""
        pref = os.path.join(self.tmp.name, "shared", "BIN ATLAS")
        self.eng.export_dirs = [pref]
        results = []
        def hammer():
            for _ in range(60):
                results.append(self.eng.export_folder()[1])
        threads = [threading.Thread(target=hammer) for _ in range(8)]
        for th in threads: th.start()
        for th in threads: th.join()
        self.assertEqual(len(results), 480); self.assertTrue(all(results))
        self.assertEqual(os.listdir(pref), [] if not any(n.startswith(".write_test") for n in os.listdir(pref)) else os.listdir(pref))

    def test_falls_back_to_next_visible_folder_then_app_folder(self):
        second = os.path.join(self.tmp.name, "Documents", "BIN ATLAS")
        self.eng.export_dirs = [self.blocked, second]
        self.assertEqual(self.eng.export_folder(), (second, False))
        path, _, preferred = self.eng.export_text_file("x")
        self.assertFalse(preferred); self.assertTrue(path.startswith(second))
        self.eng.export_dirs = [self.blocked]
        folder, preferred = self.eng.export_folder()
        self.assertFalse(preferred); self.assertEqual(os.path.basename(folder), "exports")
        self.assertTrue(os.path.isdir(folder))


class CustomFileName(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.eng = E.BinEngine(os.path.join(self.tmp.name, "t.db"))
        self.eng.export_dirs = [os.path.join(self.tmp.name, "BIN ATLAS")]

    def tearDown(self):
        self.tmp.cleanup()

    def test_clean_filename(self):
        c = E.BinEngine.clean_filename
        self.assertEqual(c("my list"), "my list")
        self.assertEqual(c("  my   list  "), "my list")
        self.assertEqual(c("report.txt"), "report"); self.assertEqual(c("Report.TXT"), "Report")   # .txt is not doubled
        self.assertEqual(c('a/b\\c:d*e?f"g<h>i|j'), "abcdefghij")                                   # illegal characters dropped
        self.assertEqual(c("2026-10-20"), "2026-10-20"); self.assertEqual(c("bins_v2"), "bins_v2")
        self.assertEqual(c("\u0645\u0644\u0641 \u0661\u0662\u0663"), "\u0645\u0644\u0641 \u0661\u0662\u0663")  # non-Latin names are fine
        for empty in ("", "   ", None, "...", "///", "***", ".txt", " . ", "?!"):
            self.assertEqual(c(empty), "", repr(empty))                                          # nothing valid left
        self.assertEqual(len(c("x" * 300)), 100)

    def test_export_path_detects_an_existing_file(self):
        path, name, preferred, exists = self.eng.export_path("my list")
        self.assertEqual((name, preferred, exists), ("my list.txt", True, False))
        self.assertEqual(os.path.dirname(path), self.eng.export_dirs[0])
        self.eng.export_text_file("first", base_name="my list")
        self.assertTrue(self.eng.export_path("my list")[3])                                      # now it exists
        self.assertFalse(self.eng.export_path("other")[3])

    def test_custom_name_is_used_and_replace_overwrites(self):
        path, name, preferred = self.eng.export_text_file("one", "bin_atlas_saved", base_name="my list")
        self.assertEqual((name, preferred), ("my list.txt", True))
        self.assertEqual(os.listdir(self.eng.export_dirs[0]), ["my list.txt"])
        with open(path, encoding="utf-8") as fh: self.assertEqual(fh.read(), "one")
        path2, _, _ = self.eng.export_text_file("two", "bin_atlas_saved", base_name="my list")    # same name: replaced
        self.assertEqual(path, path2); self.assertEqual(os.listdir(self.eng.export_dirs[0]), ["my list.txt"])
        with open(path, encoding="utf-8") as fh: self.assertEqual(fh.read(), "two")

    def test_without_a_custom_name_the_old_timestamp_name_is_unchanged(self):
        _, name, _ = self.eng.export_text_file("x", "bin_atlas_saved")
        self.assertRegex(name, r"^bin_atlas_saved_\d{8}_\d{6}\.txt$")

    def test_same_folder_fallbacks_as_before_for_custom_names(self):
        blocker = os.path.join(self.tmp.name, "blocked")
        with open(blocker, "w") as fh: fh.write("x")
        second = os.path.join(self.tmp.name, "Documents", "BIN ATLAS")
        self.eng.export_dirs = [os.path.join(blocker, "BIN ATLAS"), second]                      # first folder not allowed
        path, name, preferred, exists = self.eng.export_path("mine")
        self.assertEqual((os.path.dirname(path), preferred, exists), (second, False, False))
        self.eng.export_text_file("x", base_name="mine")
        self.assertTrue(self.eng.export_path("mine")[3])                                         # conflict check sees the fallback folder


class Hygiene(unittest.TestCase):
    def test_no_api_keys_in_source(self):
        pat = re.compile(r"\b(bl_[A-Za-z0-9_\-]{20,}|HAS-[A-Za-z0-9]{10,}|PUB-[A-Za-z0-9]{10,})")
        here = os.path.dirname(os.path.abspath(__file__))
        for f in glob.glob(os.path.join(here, "**", "*.*"), recursive=True):
            if f.endswith((".py", ".md", ".toml", ".yml", ".txt")) and os.path.basename(f) != "test_engine.py":
                with open(f, encoding="utf-8", errors="ignore") as fh:
                    self.assertIsNone(pat.search(fh.read()), f)


if __name__ == "__main__":
    unittest.main()
