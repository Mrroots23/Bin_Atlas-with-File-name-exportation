"""Tests for android_storage with a fake pyjnius (no phone needed)."""
import sys, types, unittest
from unittest import mock

import android_storage as A


class FakeContext:
    def __init__(self, perm=0, fail=()):
        self.perm, self.fail, self.started = perm, set(fail), []
    def getPackageName(self): return "com.binatlas.bin_atlas"
    def checkSelfPermission(self, name): return self.perm
    def startActivity(self, intent):
        if intent.action in self.fail:
            raise RuntimeError("ActivityNotFoundException")
        self.started.append(intent)


class FakeIntent:
    def __init__(self, action, uri=None): self.action, self.uri, self.flags = action, uri, 0
    def addFlags(self, f): self.flags |= f


def fake_jnius(sdk, manager=False, ctx=None):
    ctx = ctx or FakeContext()
    classes = {
        "android.os.Build$VERSION": types.SimpleNamespace(SDK_INT=sdk),
        "android.os.Environment": types.SimpleNamespace(isExternalStorageManager=lambda: manager),
        "android.app.ActivityThread": types.SimpleNamespace(currentApplication=lambda: ctx),
        "android.content.Intent": FakeIntent,
        "android.net.Uri": types.SimpleNamespace(parse=lambda s: ("uri", s)),
    }
    mod = types.ModuleType("jnius")
    mod.autoclass = lambda name: classes[name]
    return mod, ctx


def on_android(mod):
    return mock.patch.dict(sys.modules, {"jnius": mod}), mock.patch.object(A, "is_android", return_value=True)


class StoragePermission(unittest.TestCase):
    def test_desktop_never_asks(self):
        with mock.patch.object(A, "is_android", return_value=False):
            self.assertTrue(A.has_all_files_access()); self.assertFalse(A.open_access_settings())

    def test_android_11_plus_reads_all_files_access(self):
        for granted in (True, False):
            mod, _ = fake_jnius(34, manager=granted)
            p1, p2 = on_android(mod)
            with p1, p2:
                self.assertIs(A.has_all_files_access(), granted)

    def test_android_6_to_10_uses_storage_permission_and_old_android_is_granted(self):
        for perm, want in ((0, True), (-1, False)):
            mod, _ = fake_jnius(29, ctx=FakeContext(perm=perm))
            p1, p2 = on_android(mod)
            with p1, p2:
                self.assertIs(A.has_all_files_access(), want)
        mod, _ = fake_jnius(21)
        p1, p2 = on_android(mod)
        with p1, p2:
            self.assertTrue(A.has_all_files_access())

    def test_unknown_when_jni_fails(self):
        mod = types.ModuleType("jnius"); mod.autoclass = mock.Mock(side_effect=RuntimeError("no JVM"))
        p1, p2 = on_android(mod)
        with p1, p2:
            self.assertIsNone(A.has_all_files_access()); self.assertFalse(A.open_access_settings())

    def test_opens_the_per_app_all_files_screen_on_android_11_plus(self):
        mod, ctx = fake_jnius(34)
        p1, p2 = on_android(mod)
        with p1, p2:
            self.assertTrue(A.open_access_settings())
        self.assertEqual(len(ctx.started), 1); intent = ctx.started[0]
        self.assertEqual(intent.action, "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION")
        self.assertEqual(intent.uri, ("uri", "package:com.binatlas.bin_atlas"))
        self.assertTrue(intent.flags & A.FLAG_ACTIVITY_NEW_TASK)

    def test_falls_back_to_next_screen_when_a_phone_lacks_one(self):
        ctx = FakeContext(fail={A.ACTION_MANAGE_APP})
        mod, _ = fake_jnius(33, ctx=ctx)
        p1, p2 = on_android(mod)
        with p1, p2:
            self.assertTrue(A.open_access_settings())
        self.assertEqual(ctx.started[0].action, A.ACTION_MANAGE_ALL)
        ctx2 = FakeContext(fail={A.ACTION_MANAGE_APP, A.ACTION_MANAGE_ALL})
        mod2, _ = fake_jnius(33, ctx=ctx2)
        p1, p2 = on_android(mod2)
        with p1, p2:
            self.assertTrue(A.open_access_settings())
        self.assertEqual(ctx2.started[0].action, A.ACTION_DETAILS)
        ctx3 = FakeContext(fail={A.ACTION_MANAGE_APP, A.ACTION_MANAGE_ALL, A.ACTION_DETAILS})
        mod3, _ = fake_jnius(33, ctx=ctx3)
        p1, p2 = on_android(mod3)
        with p1, p2:
            self.assertFalse(A.open_access_settings())                          # nothing could open

    def test_android_10_and_older_open_app_details(self):
        mod, ctx = fake_jnius(29)
        p1, p2 = on_android(mod)
        with p1, p2:
            self.assertTrue(A.open_access_settings())
        self.assertEqual(ctx.started[0].action, A.ACTION_DETAILS)


if __name__ == "__main__":
    unittest.main()
