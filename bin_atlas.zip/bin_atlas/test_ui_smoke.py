"""UI smoke test with a stub `flet` (no Flet install needed).
Clicks through every tab and action to catch NameErrors / wrong wiring.
It cannot check real Flet rendering - test the APK on a device for that."""
import os, sys, tempfile, types, unittest
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ["FLET_APP_STORAGE_DATA"] = tempfile.mkdtemp()
EXPORT_DIR = os.path.join(tempfile.mkdtemp(), "BIN ATLAS")          # stands in for /storage/emulated/0/BIN ATLAS
os.environ["BINATLAS_EXPORT_DIRS"] = EXPORT_DIR
sys.path.insert(0, HERE)

import android_storage                                              # noqa: E402


class Ctl:
    def __init__(self, *a, **kw):
        self.args = a
        self.__dict__.update(kw)
        self.controls = list(a[0]) if a and isinstance(a[0], list) else list(kw.get("controls", []) or [])
        self.value = kw.get("value", None)


class FilePicker(Ctl):
    fail_save = False
    def pick_files(self, **kw): self.picked = kw
    def save_file(self, **kw):
        if FilePicker.fail_save:
            raise TypeError("save_file unsupported")
        self.saved = kw


def make_ft():
    ft = mock.MagicMock()
    for name in ("Container", "Column", "Row", "Text", "TextField", "Switch", "Image", "ProgressBar",
                 "ProgressRing", "Icon", "IconButton", "TextButton", "SafeArea", "NavigationBar",
                 "NavigationBarDestination", "AlertDialog", "SnackBar", "View", "GestureDetector"):
        setattr(ft, name, Ctl)
    ft.FilePicker = FilePicker
    return ft


def walk(c, seen=None):
    seen = seen if seen is not None else set()
    if id(c) in seen or not isinstance(c, Ctl):
        return
    seen.add(id(c))
    yield c
    for ch in list(c.controls) + list(c.args):
        if isinstance(ch, list):
            for x in ch:
                yield from walk(x, seen)
        else:
            yield from walk(ch, seen)
    for attr in ("content", "title", "actions", "options"):
        v = getattr(c, attr, None)
        if isinstance(v, list):
            for x in v:
                yield from walk(x, seen)
        elif isinstance(v, Ctl):
            yield from walk(v, seen)


class Page:
    def __init__(self):
        self.views = [Ctl()]                 # Flet's own (hidden) base view
        self.overlay, self.opened, self.closed = [], [], []
        self.clipboard = ""
        self.on_view_pop = None
        self.height = 800

    def update(self): pass
    def open(self, c): self.opened.append(c)
    def close(self, c): self.closed.append(c)
    def run_thread(self, fn, *a): fn(*a)
    def set_clipboard(self, t): self.clipboard = t


def texts(root):
    out = []
    for c in walk(root):
        if c.__class__ is Ctl and c.args and isinstance(c.args[0], str):
            out.append(c.value if isinstance(c.value, str) and c.value else c.args[0])
    return out


def click(root, label):
    for c in walk(root):
        if getattr(c, "on_click", None) and (c.args[:1] == (label,) or label in texts(c)):
            c.on_click(None)
            return True
    raise AssertionError(f"no clickable '{label}'")


def by_label(root, start):
    return next(c for c in walk(root) if c.__class__ is Ctl and str(getattr(c, "label", "")).startswith(start))


def goto(view, i):
    view.navigation_bar.on_change(types.SimpleNamespace(control=types.SimpleNamespace(selected_index=i)))


def wait_for(cond, timeout=2.0):
    import time
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.01)
    return False


def has_row(root, labels):
    """True if one Row holds all `labels`, each in its own child (i.e. they sit side by side)."""
    for c in walk(root):
        if c.__class__ is Ctl and len(c.controls) >= len(labels):
            kids = [set(texts(ch)) & set(labels) for ch in c.controls]
            if sum(1 for k in kids if k) >= len(labels) and set().union(*kids) >= set(labels):
                return True
    return False


def slot(root, name):
    """The container that holds the inline dropdown of field `name`."""
    return next(c for c in walk(root) if getattr(c, "key", None) == f"dd_{name}")


def snack_text(page):
    return " ".join(texts(page.opened[-1]))


def new_world():
    """A fresh app storage + export folder so a test starts from an empty phone."""
    return {"FLET_APP_STORAGE_DATA": tempfile.mkdtemp(), "BINATLAS_EXPORT_DIRS": os.path.join(tempfile.mkdtemp(), "BIN ATLAS")}


def chip(root, label):
    return next(c for c in walk(root) if c.__class__ is Ctl and getattr(c, "on_click", None) and texts(c) == [label])


BINLIST_OK = {"scheme": "visa", "type": "debit", "brand": "Visa Infinite", "prepaid": False,
              "number": {"luhn": True}, "country": {"name": "Italy", "alpha2": "IT", "alpha3": "ITA", "currency": "EUR"},
              "bank": {"name": "Revolut Bank UAB", "phone": "+1", "url": "x.com"}}


def build_csv():
    rows = ["BIN,Brand,Type,Category,Issuer,IssuerPhone,IssuerUrl,isoCode2,isoCode3,CountryName",
            "011300,LOCAL BRAND,DEBIT,PROPRIETARY ATM,BDO UNIBANK INC,,,PH,PHL,PHILIPPINES",
            "011301,LOCAL BRAND,CREDIT,GOLD,METROBANK,,,PH,PHL,PHILIPPINES",
            "012004,VISA,CREDIT,GOLD,STATE BANK OF INDIA,,,IN,IND,INDIA"]
    schemes = ["VISA", "MASTERCARD", "JCB", "DISCOVER"]
    for i in range(60):                                   # 60 more countries (more than one page of 40)
        code = "QWY"[i // 26] + chr(65 + i % 26)               # 60 distinct codes: QA..QZ, WA..WZ, YA..YH
        rows.append(f"{300000 + i:06d},{schemes[i % 4]},CREDIT,GOLD,FILLER BANK {i},,,{code},XXX,FILLERLAND {i:02d}")
    for i in range(60):                                   # one country with 60 banks (more than one page)
        rows.append(f"{400000 + i:06d},VISA,DEBIT,CLASSIC,ZBANK {i:03d},,,ZZ,ZZZ,ZZLAND")
    return "\n".join(rows) + "\n"


CSV = build_csv()


def fake_net(url, headers=None, timeout=None, stream=False):
    if "raw.githubusercontent" in url:
        class R:
            status_code = 200
            def iter_content(self, n): yield CSV.encode()
        return R()
    if "binlist.io" in url:
        m = mock.Mock(status_code=200); m.json.return_value = BINLIST_OK; return m
    return mock.Mock(status_code=500)


class Smoke(unittest.TestCase):
    def start(self, ft):
        sys.modules.pop("main", None)
        import main as app
        page = Page()
        app.main(page)
        view = page.views[-1]
        self.assertIsNotNone(view.navigation_bar, "app failed to start: " + " ".join(texts(view)))
        return app, page, view

    # ------------------------------------------------------------------ the big end-to-end walk
    def test_full_flow(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine._http_get", fake_net), \
                mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            self.assertEqual(len(page.views), 2)                                # hidden base view + app view
            nav = root.navigation_bar
            self.assertEqual([d.label for d in nav.destinations], ["Lookup", "Banks", "Finder", "Learn", "Saved"])
            self.assertEqual(nav.height, 58)                                    # slimmer tab bar

            # --- Lookup: compact card; Save / Copy / Refresh share one row; no pop-up
            self.assertFalse(any(str(getattr(c, "label", "")).startswith("Note to save") for c in walk(root)))
            by_label(root, "BIN").value = "52792622911"
            click(root, "Look up")
            shown = " ".join(texts(root))
            self.assertIn("52792622", shown); self.assertIn("BIN 527926", shown); self.assertIn("REVOLUT BANK UAB", shown)
            self.assertNotIn("5279262291", shown); self.assertEqual(page.opened, [])
            for gone in ("Continent", "Dial code", "Prepaid", "Commercial", "Website", "Issuer phone"):
                self.assertNotIn(gone, shown)
            self.assertTrue(has_row(root, ["Save", "Copy", "Refresh"]))
            self.assertTrue(has_row(root, ["Scheme", "Type", "Luhn"]))
            self.assertTrue(has_row(root, ["Tier / level", "Currency", "Typical length"]))
            click(root, "Copy"); self.assertEqual(page.clipboard, "52792622")
            by_label(root, "Note - saved").value = "client A"
            click(root, "Save")
            from engine import BinEngine
            self.assertEqual([(r["query"], r["bin"], r["note"]) for r in BinEngine().saved()],
                             [("52792622", "527926", "client A")])
            by_label(root, "BIN").value = "424242"; click(root, "Look up")       # a second history entry

            # --- Banks: searching with nothing chosen lists nothing and says so
            goto(root, 1)
            click(root, "Search")
            self.assertEqual(texts(page.opened[-1]), ["Please Select One Section At Least"])
            self.assertNotIn("BIN(s) found", " ".join(texts(root)))
            n_opened = len(page.opened)
            click(root, "Export TXT"); self.assertEqual(texts(page.opened[-1]), ["Please Select One Section At Least"])
            self.assertEqual(len(os.listdir(EXPORT_DIR)) if os.path.isdir(EXPORT_DIR) else 0, 0)

            with mock.patch.object(app, "DEBOUNCE", 0):
                # --- Bank field, no country chosen: nothing listed until you type; then all countries match
                click(root, "Bank")
                t = texts(root)
                self.assertTrue(any(s.startswith("Choose a country above") for s in t))
                self.assertNotIn("JPMORGAN CHASE BANK, N.A.", t)                  # clicking alone shows no banks
                self.assertEqual(page.closed, [])                                  # it is inline: no pop-up involved
                search = by_label(root, "Search"); search.value = "j"; search.on_change(None)
                t = texts(root)
                self.assertIn("JPMORGAN CHASE BANK, N.A.", t); self.assertNotIn("SUTTON BANK", t)   # starts with J only
                search.value = "a"; search.on_change(None)
                t = texts(root)
                self.assertIn("AL RAJHI BANK", t); self.assertIn("AMERICAN EXPRESS COMPANY", t)
                self.assertNotIn("SUTTON BANK", t); self.assertNotIn("PT. BANK DBS INDONESIA", t)    # start with S / P
                click(root, "Close")                                              # Close collapses the dropdown
                self.assertFalse(any("AL RAJHI BANK" == s for s in texts(root)))

                # --- download the offline database
                click(root, "Download BIN database")

                # --- Country dropdown: EVERY country at once, no "Show more"
                click(root, "Country")
                t = texts(slot(root, "country"))
                countries = [s for s in t if s.endswith(")") and " (" in s]
                self.assertGreaterEqual(len(countries), 65)                        # more than one page of 40
                self.assertNotIn("Show more", t)                                   # the whole list, just scroll
                self.assertIn("All", t); self.assertIn("Close", t)
                self.assertEqual(by_label(root, "Search").label, "Search")         # search box stays at the top
                search = by_label(root, "Search"); search.value = "phil"; search.on_change(None)
                self.assertEqual([s for s in texts(slot(root, "country")) if s.endswith(")") and " (" in s],
                                 ["\U0001F1F5\U0001F1ED Philippines (PH)"])
                click(root, "\U0001F1F5\U0001F1ED Philippines (PH)")               # choosing collapses it
                self.assertFalse(slot(root, "country").data); self.assertEqual(texts(slot(root, "country")), [])

                # --- Bank field with a country: all of that country's banks, "Show more" only here
                click(root, "Bank")
                t = texts(root)
                self.assertIn("Banks in \U0001F1F5\U0001F1ED Philippines (PH). Type below to narrow the list.", t)
                self.assertTrue({"BDO UNIBANK INC", "METROBANK"} <= set(t))
                self.assertNotIn("STATE BANK OF INDIA", t); self.assertNotIn("Show more", texts(slot(root, "bank")))
                search = by_label(root, "Search"); search.value = "b"; search.on_change(None)   # starts with B
                rows = [s for s in texts(slot(root, "bank")) if s not in ("Bank", "Close") and "Banks in" not in s]
                self.assertEqual(rows, ["BDO UNIBANK INC"])                          # typed "b": only names starting with B
                click(root, "BDO UNIBANK INC")
                click(root, "Type"); self.assertIn("DEBIT", texts(root)); self.assertNotIn("CREDIT", texts(root))
                click(root, "DEBIT")
                click(root, "Search")
                t = " ".join(texts(root))
                self.assertIn("011300", t); self.assertNotIn("011301", t); self.assertIn("1 BIN(s) found", t)
                click(root, "Export TXT")
                self.assertIn("DATE : ", page.clipboard); self.assertIn("BDO UNIBANK INC", page.clipboard)
                self.assertEqual(len(os.listdir(EXPORT_DIR)), 1)

                # --- paging only in the bank list: country with 60 banks -> 40 then "Show more" -> 60
                click(root, "Reset")
                from engine import flag_emoji
                click(root, "Country"); search = by_label(root, "Search"); search.value = "zzland"; search.on_change(None)
                click(root, f"{flag_emoji('ZZ')} Zzland (ZZ)")
                click(root, "Bank")
                self.assertEqual(len([s for s in texts(root) if s.startswith("ZBANK")]), 40)
                self.assertIn("Show more", texts(slot(root, "bank")))              # the only field with "Show more"
                click(slot(root, "bank"), "Show more")
                self.assertEqual(len([s for s in texts(root) if s.startswith("ZBANK")]), 60)
                self.assertNotIn("Show more", texts(slot(root, "bank")))
                click(root, "Close")
                click(root, "Reset")

                # --- Back closes an open dropdown first (no exit hint)
                click(root, "Bank"); shown_before = len(page.opened)
                page.on_view_pop(None)
                self.assertNotIn("Choose a country above to list its banks, or type a bank name to search all countries.", texts(root))
                self.assertEqual(len(page.opened), shown_before)

            # --- BIN Finder
            goto(root, 2)
            count = by_label(root, "How many BINs?")
            self.assertEqual(count.value, "25")
            self.assertEqual(chip(root, "25").bgcolor, "#0F5566"); self.assertNotEqual(chip(root, "50").bgcolor, "#0F5566")
            click(root, "Find BINs")                                                # no type chosen yet
            self.assertEqual(texts(page.opened[-1]), ["Select Type Card First"])
            click(root, "50"); self.assertEqual(count.value, "50")                  # quick quantity fills the field
            self.assertEqual(chip(root, "50").bgcolor, "#0F5566"); self.assertNotEqual(chip(root, "25").bgcolor, "#0F5566")
            count.value = "100"; count.on_change(None)                              # typing highlights the matching chip
            self.assertEqual(chip(root, "100").bgcolor, "#0F5566")
            count.value = "37"; count.on_change(None)
            self.assertTrue(all(chip(root, q).bgcolor != "#0F5566" for q in ("10", "25", "50", "100")))
            click(root, "Mix"); self.assertEqual(chip(root, "Mix").bgcolor, "#0F5566")
            count.value = "10"; count.on_change(None); click(root, "Find BINs")
            self.assertIn("10 BIN(s) from 10 countries", " ".join(texts(root)))

            click(root, "Select Card Type")                                         # same inline dropdown
            t = texts(root)
            for want in ("Mix (all types)", "VISA", "MASTERCARD", "AMERICAN EXPRESS", "JCB", "DISCOVER"):
                self.assertIn(want, t)
            self.assertNotIn("All", texts(slot(root, "ftype")))
            self.assertNotIn("Show more", texts(slot(root, "ftype")))
            click(root, "JCB")
            self.assertTrue(all(chip(root, q).bgcolor != "#0F5566" for q in ("Visa", "Mastercard", "Amex", "Mix")))
            count.value = "20"; count.on_change(None); click(root, "Find BINs")
            t = " ".join(texts(root))
            self.assertIn("15 BIN(s) from 15 countries - only 15 match", t)         # only 15 JCB BINs exist
            count.value = "250"; click(root, "Find BINs")
            self.assertEqual(texts(page.opened[-1]), ["The maximum is 100 BINs."]); self.assertEqual(count.value, "100")
            # country field: "All" by default; one country -> BINs only from it
            from engine import flag_emoji
            self.assertIn("All", texts(root)); self.assertIn("Country", texts(root))
            click(root, "Country")
            t = texts(slot(root, "fcountry"))
            self.assertIn("All", t); self.assertIn("Close", t); self.assertNotIn("Show more", t)
            self.assertGreaterEqual(len([s for s in t if s.endswith(")") and " (" in s]), 65)   # every country, just scroll
            search = by_label(root, "Search"); search.value = "phil"; search.on_change(None)
            click(root, f"{flag_emoji('PH')} Philippines (PH)")
            self.assertFalse(slot(root, "fcountry").data)
            click(root, "Mix"); count.value = "10"; count.on_change(None); click(root, "Find BINs")
            t = " ".join(texts(root))
            self.assertIn(f"2 BIN(s) from {flag_emoji('PH')} Philippines (PH) - only 2 match", t)   # PH has just 2 BINs
            click(root, "Country")
            search = by_label(root, "Search"); search.value = "zzland"; search.on_change(None)
            click(root, f"{flag_emoji('ZZ')} Zzland (ZZ)")
            click(root, "Find BINs")
            t = texts(root)
            self.assertIn(f"10 BIN(s) from {flag_emoji('ZZ')} Zzland (ZZ)", " ".join(t))        # 10 from ONE country (not capped at 3)
            self.assertEqual(len([s for s in t if s.startswith("ZBANK")]) or len([s for s in t if "ZBANK" in s]), 10)
            click(root, "Country"); click(root, "All")                                           # back to All: different countries again
            click(root, "Find BINs")
            self.assertIn("10 BIN(s) from 10 countries", " ".join(texts(root)))
            click(root, "Select Card Type"); click(root, "JCB")
            count.value = "20"; count.on_change(None); click(root, "Find BINs")
            tile = next(c for c in walk(root) if c.__class__ is Ctl and getattr(c, "on_click", None)
                        and any("JCB" in s and "·" in s for s in texts(c)) and len(texts(c)) > 3)
            tile.on_click(None)
            self.assertIn("BIN details", " ".join(texts(root))); self.assertTrue(has_row(root, ["Save", "Copy", "Refresh"]))
            page.on_view_pop(None)                                                  # back -> Finder with results kept
            self.assertIn("BIN Finder", " ".join(texts(root))); self.assertIn("BIN(s) from", " ".join(texts(root)))
            click(root, "Clear")
            self.assertEqual(count.value, "25"); self.assertEqual(chip(root, "25").bgcolor, "#0F5566")
            self.assertNotIn("BIN(s) from", " ".join(texts(root)))

            # --- Learn: multi-number Luhn
            goto(root, 3)
            self.assertIn("3 pass · 3 fail", " ".join(texts(root)))

            # --- Saved: actions pinned outside the scrolling lists; per-BIN trash; confirmations
            goto(root, 4)
            saved_view = root.controls[0].args[0].content.content    # SafeArea -> tap layer -> body -> saved view
            scrolling, pinned = saved_view.controls
            self.assertTrue(scrolling.scroll and scrolling.expand)
            self.assertNotIn("Export TXT", texts(scrolling)); self.assertNotIn("Clear history", texts(scrolling))
            self.assertTrue({"Export TXT", "Clear history"} <= set(texts(pinned)))
            t = texts(root)
            self.assertIn("Saved (1)", t); self.assertIn("History (2)", t); self.assertIn("\u270E client A", t)
            trash = lambda kind: [c for c in walk(root) if getattr(c, "tooltip", "") == "Delete from " + kind]
            self.assertEqual((len(trash("saved")), len(trash("history"))), (1, 2))   # one trash icon per BIN, both lists

            trash("history")[0].on_click(None)                                       # history item: ask first
            dlg = page.opened[-1]
            self.assertIn("Delete BIN \u26A0\uFE0F", texts(dlg)); self.assertTrue({"YES", "NO"} <= set(texts(dlg)))
            click(dlg, "NO"); self.assertIn("History (2)", texts(root))              # NO keeps it
            trash("history")[0].on_click(None); click(page.opened[-1], "YES")        # YES deletes only that entry
            self.assertIn("History (1)", texts(root)); self.assertIn("Saved (1)", texts(root))
            trash("saved")[0].on_click(None); click(page.opened[-1], "NO"); self.assertIn("Saved (1)", texts(root))
            click(root, "Clear history")
            dlg = page.opened[-1]
            self.assertIn("Delete History \u26A0\uFE0F", texts(dlg)); self.assertTrue({"DELETE", "CANCEL"} <= set(texts(dlg)))
            click(dlg, "CANCEL"); self.assertIn("History (1)", texts(root))
            click(root, "Clear history"); click(page.opened[-1], "DELETE")
            self.assertIn("History (0)", texts(root)); self.assertIn("Saved (1)", texts(root))   # saved BINs survive

            # --- tapping a saved BIN opens its details in place; Back returns to Saved
            next(c for c in walk(root) if c.__class__ is Ctl and getattr(c, "on_click", None)
                 and "\u270E client A" in texts(c)).on_click(None)
            self.assertIn("BIN details", " ".join(texts(root)))
            shown_before = len(page.opened)
            page.on_view_pop(None)
            self.assertIn("Saved (1)", " ".join(texts(root))); self.assertEqual(len(page.opened), shown_before)
            with mock.patch.object(app, "hard_exit") as hard:
                page.on_view_pop(None)
                self.assertIn("Press back again to exit", texts(page.opened[-1])); self.assertFalse(hard.called)
                page.on_view_pop(None)
                self.assertTrue(wait_for(lambda: hard.called)); self.assertEqual(len(page.views), 1)

            click(root, "Export TXT")                                               # Saved: name modal first
            dlg = page.opened[-1]
            self.assertIn("Export TXT", texts(dlg)); self.assertTrue({"CANCEL", "SAVE"} <= set(texts(dlg)))
            by_label(dlg, "File name").value = "flow export"; click(dlg, "SAVE")
            self.assertIn("52792622\n\U0001F517 TYPE \u279C VISA", page.clipboard)
            self.assertIn("\u2139\uFE0F NOTE \u279C client A", page.clipboard)
            self.assertNotIn("5279262291", page.clipboard)
            self.assertTrue(os.path.exists(os.path.join(EXPORT_DIR, "flow export.txt")))
            self.assertEqual(snack_text(page), f"Saved 1 entries to {os.path.join(EXPORT_DIR, 'flow export.txt')}")

    # ------------------------------------------------------------------ storage permission pop-up
    def test_storage_permission_popup(self):
        blocker = os.path.join(tempfile.mkdtemp(), "blocked")
        with open(blocker, "w") as fh: fh.write("x")
        env = {"BINATLAS_EXPORT_DIRS": os.path.join(blocker, "BIN ATLAS"), "FLET_APP_STORAGE_DATA": tempfile.mkdtemp()}
        ft = make_ft()
        granted = {"v": False}
        opener = mock.Mock(return_value=True)
        with mock.patch.dict(os.environ, env), mock.patch.dict(sys.modules, {"flet": ft}), \
                mock.patch("engine.BinEngine.prewarm"), \
                mock.patch.object(android_storage, "has_all_files_access", side_effect=lambda: granted["v"]), \
                mock.patch.object(android_storage, "open_access_settings", opener):
            # first launch without access -> pop-up straight away
            app, page, root = self.start(ft)
            dlg = page.opened[-1]
            self.assertTrue({"Permission Required", "ALLOW"} <= set(texts(dlg)))
            self.assertTrue(any("access all your files" in s for s in texts(dlg)))
            x_button = next(c for c in walk(dlg) if getattr(c, "on_click", None) and getattr(c, "width", None) == 40)
            x_button.on_click(None)                                                 # red X: closes, UI is normal
            self.assertIn(dlg, page.closed); self.assertIn("Lookup", [d.label for d in root.navigation_bar.destinations])
            self.assertFalse(opener.called)

            # exporting without access -> the pop-up comes back EVERY time; X lets the export carry on
            goto(root, 1)
            click(root, "Country"); click(root, "United States (US)" if False else next(s for s in texts(root) if s.endswith("(US)")))
            click(root, "Search")
            for attempt in range(2):
                opened = len(page.opened)
                click(root, "Export TXT")
                dlg = page.opened[-1]
                self.assertEqual(len(page.opened), opened + 1); self.assertIn("Permission Required", texts(dlg))
                next(c for c in walk(dlg) if getattr(c, "on_click", None) and getattr(c, "width", None) == 40).on_click(None)
                self.assertIn("DATE : ", page.clipboard)                            # X -> export still happens (fallback folder)
            # importing without access -> pop-up too
            click(root, "Import CSV file"); self.assertIn("Permission Required", texts(page.opened[-1]))
            click(page.opened[-1], "ALLOW")                                         # ALLOW -> Android's settings screen
            self.assertEqual(opener.call_count, 1)
            # access granted -> no more pop-ups, actions just work
            granted["v"] = True
            opened = len(page.opened)
            click(root, "Export TXT"); self.assertNotIn("Permission Required", " ".join(texts(page.opened[-1])))
            click(root, "Import CSV file"); self.assertTrue(hasattr(root, "navigation_bar"))
            self.assertFalse(any("Permission Required" in " ".join(texts(d)) for d in page.opened[opened:]))

            # ALLOW when this phone cannot open the screen -> clear manual steps instead of nothing
            granted["v"] = False; opener.return_value = False
            click(root, "Export TXT"); click(page.opened[-1], "ALLOW")
            self.assertTrue(texts(page.opened[-1])[0].startswith("Open Android Settings"))

            # a later launch does not nag at start-up again (only the first launch asks) ...
            app2, page2, root2 = self.start(ft)
            self.assertEqual(page2.opened, [])
            # ... but exporting still asks
            goto(root2, 1); click(root2, "Country"); click(root2, next(s for s in texts(root2) if s.endswith("(US)")))
            click(root2, "Search"); click(root2, "Export TXT")
            self.assertIn("Permission Required", texts(page2.opened[-1]))

    def test_no_popup_when_access_already_granted(self):
        ft = make_ft()
        with mock.patch.dict(os.environ, {"FLET_APP_STORAGE_DATA": tempfile.mkdtemp()}), \
                mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine.BinEngine.prewarm"), \
                mock.patch.object(android_storage, "has_all_files_access", return_value=True):
            app, page, root = self.start(ft)
            self.assertEqual(page.opened, [])

    # ------------------------------------------------------------------ smaller checks
    def test_export_falls_back_with_clear_message(self):
        blocker = os.path.join(tempfile.mkdtemp(), "blocked")
        with open(blocker, "w") as fh: fh.write("x")
        ft = make_ft()
        with mock.patch.dict(os.environ, {"BINATLAS_EXPORT_DIRS": os.path.join(blocker, "BIN ATLAS")}), \
                mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine.BinEngine.prewarm"), \
                mock.patch.object(FilePicker, "fail_save", True):
            app, page, root = self.start(ft)
            goto(root, 1)
            click(root, "Country"); click(root, next(s for s in texts(root) if s.endswith("(US)")))
            click(root, "Search"); click(root, "Export TXT")
            msg = " ".join(texts(page.opened[-1]))
            self.assertIn("File: ", msg); self.assertIn("Storage", msg)
            self.assertIn("DATE : ", page.clipboard)

    def test_back_hint_expires(self):
        ft = make_ft()
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            with mock.patch.object(app, "hard_exit") as hard, mock.patch.object(app, "EXIT_WINDOW", 0.0):
                page.on_view_pop(None); page.on_view_pop(None)                  # window of 0 s: never a double press
                self.assertFalse(wait_for(lambda: hard.called, 0.5))

    def test_settings_dialog(self):
        ft = make_ft()
        opener = mock.Mock(return_value=True)
        with mock.patch.dict(sys.modules, {"flet": ft}), mock.patch("engine.BinEngine.prewarm"), \
                mock.patch.object(android_storage, "open_access_settings", opener):
            app, page, root = self.start(ft)
            next(c for c in walk(root) if getattr(c, "tooltip", "") == "API keys & sources").on_click(None)
            dlg = page.opened[-1]
            handy = by_label(dlg, "HandyAPI")
            handy.value = "HAS-" + "q" * 20
            next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
            self.assertTrue(any("SECRET" in s for s in texts(dlg)))
            handy.value = "PUB-" + "q" * 20
            with mock.patch("engine._http_get", return_value=mock.Mock(status_code=401)):
                next(a for a in dlg.actions if a.args[0] == "Save & test").on_click(None)
            self.assertTrue(any("key rejected" in s for s in texts(dlg)))
            self.assertTrue(any("venelinkochev" in s for s in texts(dlg)))
            self.assertTrue(any(s.startswith("\u2713 TXT files are saved to:") and EXPORT_DIR in s for s in texts(dlg)))
            click(dlg, "Check storage")
            click(dlg, "Allow access"); self.assertEqual(opener.call_count, 1)    # same screen as the pop-up's ALLOW

    # ------------------------------------------------------------------ Saved > Export TXT name modal
    def seed_saved(self):
        from engine import BinEngine
        eng = BinEngine()
        eng.lookup("424242", allow_network=False); eng.save_query("424242", "first")
        eng.lookup("510510", allow_network=False); eng.save_query("510510", "second")

    def test_export_name_modal(self):
        world = new_world()
        ft = make_ft()
        with mock.patch.dict(os.environ, world), mock.patch.dict(sys.modules, {"flet": ft}), \
                mock.patch("engine.BinEngine.prewarm"):
            self.seed_saved()
            out = world["BINATLAS_EXPORT_DIR" "S"]
            app, page, root = self.start(ft)
            goto(root, 4)
            files = lambda: sorted(os.listdir(out)) if os.path.isdir(out) else []

            # 1) the modal: name field (auto-focused), CANCEL, SAVE - no automatic name
            click(root, "Export TXT")
            dlg = page.opened[-1]
            self.assertTrue(dlg.modal)
            self.assertIn("Export TXT", texts(dlg)); self.assertTrue({"CANCEL", "SAVE"} <= set(texts(dlg)))
            name = by_label(dlg, "File name")
            self.assertTrue(name.autofocus)                                       # keyboard comes up straight away
            self.assertEqual(name.value, "")                                      # nothing pre-filled
            self.assertTrue(any(".txt extension is added automatically" in s for s in texts(dlg)))
            error = next(c for c in walk(dlg) if c.__class__ is Ctl and c.args[:1] == ("Please enter name to save",))
            self.assertFalse(error.visible); self.assertEqual(error.color, "#FF9800")      # orange, like the other warnings
            self.assertEqual(files(), [])

            # 2) validation: empty / only symbols / only spaces -> inline orange error, nothing saved, modal stays
            for bad in ("", "   ", "///", "***", ".txt", "?!"):
                name.value = bad; click(dlg, "SAVE")
                self.assertTrue(error.visible, repr(bad)); self.assertNotIn(dlg, page.closed); self.assertEqual(files(), [])
            name.value = "a"; name.on_change(None)
            self.assertFalse(error.visible)                                       # the error clears while typing

            # 3) CANCEL closes without saving
            click(dlg, "CANCEL"); self.assertIn(dlg, page.closed); self.assertEqual(files(), [])

            # 4) SAVE with a name: .txt added, success banner unchanged (count + real path + custom name)
            click(root, "Export TXT"); dlg = page.opened[-1]
            by_label(dlg, "File name").value = "my list"; click(dlg, "SAVE")
            self.assertEqual(files(), ["my list.txt"])
            self.assertEqual(snack_text(page), f"Saved 2 entries to {os.path.join(out, 'my list.txt')}")
            self.assertEqual(page.opened[-1].bgcolor, "#00E676")                  # same green banner as before
            with open(os.path.join(out, "my list.txt"), encoding="utf-8") as fh:
                self.assertEqual(fh.read(), page.clipboard)
            self.assertIn("first", page.clipboard); self.assertIn("second", page.clipboard)

            # 5) same name again (even typed with .txt) -> second small modal, orange warning, REPLACE / EDIT NAME
            before = len(page.opened)
            click(root, "Export TXT"); dlg = page.opened[-1]
            by_label(dlg, "File name").value = "my list.txt"; click(dlg, "SAVE")
            self.assertIn(dlg, page.closed)                                       # first modal closed
            warn = page.opened[-1]
            self.assertEqual(len(page.opened), before + 2)
            self.assertTrue({"This name already exists", "my list.txt", "REPLACE", "EDIT NAME"} <= set(texts(warn)))
            w = next(c for c in walk(warn) if c.__class__ is Ctl and c.args[:1] == ("This name already exists",))
            self.assertEqual(w.color, "#FF9800")
            self.assertEqual(files(), ["my list.txt"])                            # nothing written yet

            # 6) EDIT NAME -> first modal again with the previous text, focus again
            click(warn, "EDIT NAME")
            self.assertIn(warn, page.closed)
            again = page.opened[-1]
            self.assertIn("Export TXT", texts(again))
            f2 = by_label(again, "File name")
            self.assertEqual(f2.value, "my list.txt"); self.assertTrue(f2.autofocus)
            f2.value = "my list 2"; click(again, "SAVE")                           # a free name saves normally
            self.assertEqual(files(), ["my list 2.txt", "my list.txt"])
            self.assertTrue(snack_text(page).endswith(os.path.join(out, "my list 2.txt")))

            # 7) REPLACE overwrites the old file and completes the save
            path = os.path.join(out, "my list.txt")
            with open(path, "w", encoding="utf-8") as fh: fh.write("OLD CONTENT")
            click(root, "Export TXT"); dlg = page.opened[-1]
            by_label(dlg, "File name").value = "my list"; click(dlg, "SAVE")
            warn = page.opened[-1]; self.assertIn("This name already exists", texts(warn))
            with open(path, encoding="utf-8") as fh: self.assertEqual(fh.read(), "OLD CONTENT")   # still untouched
            click(warn, "REPLACE")
            with open(path, encoding="utf-8") as fh: self.assertNotEqual(fh.read(), "OLD CONTENT")
            self.assertEqual(files(), ["my list 2.txt", "my list.txt"])
            self.assertEqual(snack_text(page), f"Saved 2 entries to {path}")

            # 8) keyboard "done" saves too; non-Latin names work
            click(root, "Export TXT"); dlg = page.opened[-1]
            f3 = by_label(dlg, "File name"); f3.value = "\u0645\u0644\u0641 \u0661"; f3.on_submit(None)
            self.assertIn("\u0645\u0644\u0641 \u0661.txt", files())

            # 9) Banks > Export TXT is unchanged: still the automatic dated name, no modal
            goto(root, 1)
            click(root, "Country"); click(root, next(s for s in texts(root) if s.endswith("(US)"))); click(root, "Search")
            opened = len(page.opened)
            click(root, "Export TXT")
            self.assertTrue(any(f.startswith("bin_atlas_banks_") for f in files()))
            self.assertNotIn("Export TXT", " ".join(texts(page.opened[-1])))

    def test_export_with_nothing_saved(self):
        ft = make_ft()
        with mock.patch.dict(os.environ, new_world()), mock.patch.dict(sys.modules, {"flet": ft}), \
                mock.patch("engine.BinEngine.prewarm"):
            app, page, root = self.start(ft)
            goto(root, 4); n = len(page.opened)
            click(root, "Export TXT")
            self.assertEqual(snack_text(page), "Nothing to export yet.")
            self.assertEqual(len(page.opened), n + 1)                             # only the notice, no modal

    def test_export_name_modal_after_permission_popup_and_same_folders(self):
        """Permission pop-up first (unchanged), then the name modal; the folder logic is the old one."""
        blocker = os.path.join(tempfile.mkdtemp(), "blocked")
        with open(blocker, "w") as fh: fh.write("x")
        second = os.path.join(tempfile.mkdtemp(), "Documents", "BIN ATLAS")
        world = {"FLET_APP_STORAGE_DATA": tempfile.mkdtemp(),
                 "BINATLAS_EXPORT_DIRS": os.pathsep.join([os.path.join(blocker, "BIN ATLAS"), second])}
        ft = make_ft(); granted = {"v": False}; opener = mock.Mock(return_value=True)
        with mock.patch.dict(os.environ, world), mock.patch.dict(sys.modules, {"flet": ft}), \
                mock.patch("engine.BinEngine.prewarm"), \
                mock.patch.object(android_storage, "has_all_files_access", side_effect=lambda: granted["v"]), \
                mock.patch.object(android_storage, "open_access_settings", opener):
            self.seed_saved()
            app, page, root = self.start(ft)
            dlg = page.opened[-1]; self.assertIn("Permission Required", texts(dlg))   # first launch pop-up
            next(c for c in walk(dlg) if getattr(c, "on_click", None) and getattr(c, "width", None) == 40).on_click(None)
            goto(root, 4)
            click(root, "Export TXT")                                              # no access -> pop-up before the modal
            pop = page.opened[-1]; self.assertIn("Permission Required", texts(pop))
            click(pop, "ALLOW"); self.assertEqual(opener.call_count, 1)            # ALLOW: settings, no name modal
            self.assertNotIn("File name", [getattr(c, "label", "") for c in walk(page.opened[-1])])
            click(root, "Export TXT"); pop = page.opened[-1]
            next(c for c in walk(pop) if getattr(c, "on_click", None) and getattr(c, "width", None) == 40).on_click(None)
            dlg = page.opened[-1]; self.assertIn("Export TXT", texts(dlg))          # X -> carries on to the name modal
            by_label(dlg, "File name").value = "fallback name"; click(dlg, "SAVE")
            # /storage/emulated/0/BIN ATLAS (first) is not writable -> the second visible folder, same as before
            self.assertTrue(os.path.exists(os.path.join(second, "fallback name.txt")))
            self.assertIn(second, snack_text(page)); self.assertIn("fallback name.txt", snack_text(page))
            self.assertIn("Saved to ", snack_text(page))
            # a conflict is detected in that same fallback folder
            click(root, "Export TXT"); pop = page.opened[-1]
            next(c for c in walk(pop) if getattr(c, "on_click", None) and getattr(c, "width", None) == 40).on_click(None)
            dlg = page.opened[-1]; by_label(dlg, "File name").value = "fallback name"; click(dlg, "SAVE")
            self.assertIn("This name already exists", texts(page.opened[-1]))

    # ------------------------------------------------------------------ dropdown details
    def test_dropdown_ui_details(self):
        ft = make_ft()
        with mock.patch.dict(os.environ, new_world()), mock.patch.dict(sys.modules, {"flet": ft}), \
                mock.patch("engine.BinEngine.prewarm"), mock.patch("engine._http_get", fake_net):
            app, page, root = self.start(ft)
            tap_layer = root.controls[0].args[0]                                   # SafeArea -> GestureDetector (tap outside)
            self.assertTrue(callable(tap_layer.on_tap)); self.assertTrue(tap_layer.expand)
            goto(root, 1)
            country = slot(root, "country")
            self.assertTrue(hasattr(country, "animate_size"))                      # smooth expand / collapse
            for n in ("country", "scheme", "bank", "type", "level"):
                self.assertFalse(slot(root, n).data)

            # opens inline, right under its field; height follows the screen (about 45% for the whole dropdown)
            for height, want in ((800, 220), (2000, 340), (500, 150)):
                page.height = height
                click(root, "Country"); self.assertTrue(country.data)
                box = next(c for c in walk(country) if isinstance(getattr(c, "height", None), int) and c.height >= 100)
                self.assertEqual(box.height, want, height)
                click(root, "Country"); self.assertFalse(country.data)              # tapping the field again collapses it

            # full-width rows, scrollbar anchored to the far right: stretched column, right gutter, left-aligned text
            page.height = 800
            click(root, "Country")
            listing = next(c for c in walk(country) if c.__class__ is Ctl and getattr(c, "scroll", None) and c.controls)
            self.assertEqual(listing.horizontal_alignment, ft.CrossAxisAlignment.STRETCH)
            rows = [c for c in listing.controls if getattr(c, "on_click", None)]
            self.assertTrue(rows)
            for r in rows:
                self.assertEqual(r.alignment, ft.alignment.center_left); self.assertIsNotNone(r.margin)
            panel_col = next(c for c in walk(country) if c.__class__ is Ctl and "Close" in texts(c) and len(c.controls) >= 4)
            self.assertEqual(panel_col.horizontal_alignment, ft.CrossAxisAlignment.STRETCH)
            self.assertEqual(texts(panel_col)[0], "Country")                         # search stays on top, Close at the bottom
            self.assertEqual(getattr(panel_col.controls[2], "label", None), "Search")
            self.assertEqual(texts(panel_col.controls[-1]), ["Close"])

            # tap outside closes; tap inside the dropdown does not
            absorber = next(c for c in walk(country) if hasattr(c, "on_tap"))
            absorber.on_tap(None); self.assertTrue(country.data)
            tap_layer.on_tap(None); self.assertFalse(country.data); self.assertIsNone(country.content)
            tap_layer.on_tap(None)                                                   # nothing open: harmless

            # pressing any other button also collapses it (Search / Reset / chips ...)
            click(root, "Bank"); self.assertTrue(slot(root, "bank").data)
            click(root, "Search"); self.assertFalse(slot(root, "bank").data)
            self.assertEqual(texts(page.opened[-1]), ["Please Select One Section At Least"])
            click(root, "Country"); click(root, "Bank")                             # opening another closes the first
            self.assertFalse(country.data); self.assertTrue(slot(root, "bank").data)
            click(root, "Reset"); self.assertFalse(slot(root, "bank").data)

            # Finder: same behaviour; quick chips collapse it; tapping the number field too
            goto(root, 2)
            click(root, "Select Card Type"); self.assertTrue(slot(root, "ftype").data)
            click(root, "50"); self.assertFalse(slot(root, "ftype").data)
            click(root, "Country"); self.assertTrue(slot(root, "fcountry").data)
            by_label(root, "How many BINs?").on_focus(None); self.assertFalse(slot(root, "fcountry").data)
            click(root, "Country"); click(root, "Select Card Type")
            self.assertFalse(slot(root, "fcountry").data); self.assertTrue(slot(root, "ftype").data)
            ftype_slot = slot(root, "ftype")
            goto(root, 1); self.assertFalse(ftype_slot.data)                         # leaving the tab closes it
            click(root, "Bank"); page.on_view_pop(None); self.assertFalse(slot(root, "bank").data)   # Back closes it first

    def test_permission_popup_uses_the_app_colours(self):
        blocker = os.path.join(tempfile.mkdtemp(), "blocked")
        with open(blocker, "w") as fh: fh.write("x")
        env = {"BINATLAS_EXPORT_DIRS": os.path.join(blocker, "BIN ATLAS"), "FLET_APP_STORAGE_DATA": tempfile.mkdtemp()}
        ft = make_ft()
        with mock.patch.dict(os.environ, env), mock.patch.dict(sys.modules, {"flet": ft}), \
                mock.patch("engine.BinEngine.prewarm"), \
                mock.patch.object(android_storage, "has_all_files_access", return_value=False):
            app, page, root = self.start(ft)
            dlg = page.opened[-1]
            x = next(c for c in walk(dlg) if getattr(c, "on_click", None) and getattr(c, "width", None) == 40)
            allow = next(c for c in walk(dlg) if getattr(c, "on_click", None) and texts(c) == ["ALLOW"])
            self.assertEqual(x.bgcolor, "#00F0FF"); self.assertEqual(allow.bgcolor, "#00F0FF")   # app's cyan, no red
            self.assertEqual(next(c for c in walk(x) if hasattr(c, "args") and c.args and not isinstance(c.args[0], str)).color, "#04141C")
            allow_text = next(c for c in walk(allow) if c.args[:1] == ("ALLOW",))
            self.assertEqual(allow_text.color, "#04141C")                                         # dark text on cyan
            colours = {str(getattr(c, "bgcolor", "")).upper() for c in walk(dlg)} | {str(getattr(c, "color", "")).upper() for c in walk(dlg)}
            self.assertNotIn("#DC143C", colours)



if __name__ == "__main__":
    unittest.main()
