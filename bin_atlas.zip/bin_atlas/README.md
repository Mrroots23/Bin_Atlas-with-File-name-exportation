# BIN Atlas v1.5

BIN lookup, issuer search, BIN finder and Luhn practice. Flet 0.28.3 (Python), builds to Android.

## Tabs
- **Lookup** - one or many BINs (comma separated, 6 to 8 digits each). Compact card: Save / Copy / Refresh on one row.
- **Banks** - filters Country > Brand > Bank > Type > Level. Each field opens a dropdown directly under it
  (search box on top, a list whose height follows the screen (~45% for the whole dropdown) that you scroll with the
  scrollbar at the far right, Close button at the bottom). It expands/collapses smoothly, tapping anywhere outside (or pressing
  another button, or Back) closes it, and the open field is highlighted. Searching with no filter chosen shows
  "Please Select One Section At Least".
  - Country, Brand, Type, Level list everything at once (just scroll).
  - **Bank**: with a country chosen it lists that country's banks ("Show more" for the rest; typing narrows them).
    With no country it lists nothing until you type: 1-2 letters show names that START with them ("J" -> JPMORGAN...),
    3+ letters match anywhere with the "starts with" ones first.
- **Finder** - random BINs: quantity (10/25/50/100 or your own, up to 100), **country** ("All" by default = different
  countries, at most 3 per country; or pick one country = BINs only from it) and card type (Visa / Mastercard / Amex / Mix
  or any other from the dropdown). No type chosen -> "Select Type Card First".
- **Learn** - multi-number Luhn checker with step-by-step explanation (on-device, nothing stored).
- **Saved** - saved numbers (exactly as searched, up to 8 digits) with notes + history. Export TXT / Clear history are
  pinned above the tab bar. A red trash icon on every BIN deletes just that one (after a confirmation).
  **Export TXT** asks for a file name first (keyboard opens at once; ".txt" is added automatically). An empty / symbol-only
  name shows "Please enter name to save". If that name already exists in the destination folder a small dialog offers
  REPLACE or EDIT NAME. Folders are unchanged: /storage/emulated/0/BIN ATLAS, then the fallbacks below.

## Back button
Closes an open dropdown, or leaves BIN details back to its tab. On a main tab press back twice within 2 s to exit.

## Storage permission
First launch shows a "Permission Required" pop-up (app colours). ALLOW opens Android's "All files access" screen for this app
(via pyjnius); the red X closes it. Exporting or importing without access shows the pop-up again every time until it is granted.
TXT files go to `/storage/emulated/0/BIN ATLAS` (fallbacks: Documents/BIN ATLAS, Download/BIN ATLAS, app folder).

## Digits
At most the first 8 digits (the BIN/IIN) are sent, shown, saved or exported. Extra digits are dropped silently.

## Sources and keys
binlist.io -> HandyAPI -> binlist.net with automatic failover. Keys live only on the phone (gear icon).
Use the HandyAPI publishable key (PUB-...); the secret key (HAS-...) is refused.

## Run / test / build
    pip install flet==0.28.3 requests
    python main.py
    python -m unittest test_engine test_ui_smoke test_storage_permission -v
    flet build apk --project "BIN Atlas" --org com.binatlas

## Credits
Offline BIN database: venelinkochev/bin-list-data (CC BY 4.0). Public BIN data may be incomplete or outdated.

## Launch screen note
The pale screen before the logo splash is drawn by Flet's own Flutter layer before any Python runs, so app code cannot
colour it. The GitHub workflow in `GITHUB_WORKFLOW_for_zip_upload.yml` also uploads the generated `main.dart` as an artifact
(`flutter-main-dart`) so a proper fix can be written against the real file.
