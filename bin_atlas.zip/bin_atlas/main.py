"""BIN Atlas v1.2 - BIN lookup, issuer search and Luhn practice (Flet, Android-ready).

Tabs: Lookup | Banks | Learn (Luhn checker) | Saved      Gear icon: API keys & sources
"""
import os
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

import flet as ft

import android_storage
from logo_data import LOGO_B64
# NOTE: `engine` (and with it `requests` and `sqlite3`) is imported inside main()/build_app(),
# AFTER the dark splash is on screen, so those imports no longer delay the first dark frame.

ICONS = getattr(ft, "Icons", None) or ft.icons   # Flet renamed ft.icons -> ft.Icons

BG, CARD_BG, BOX_BG = "#04141C", "#081E29", "#0B2532"
CYAN, BORDER, WHITE, MUTED = "#00F0FF", "#134E5E", "#FFFFFF", "#7A9CAE"
GOLD, ORANGE, GREEN, RED = "#FFD700", "#FF9800", "#00E676", "#FF5252"
PAGE_SIZE = 40          # rows added per "Show more" in result lists
PICK_PAGE = 40          # rows per page in the BANK picker ("Show more"); other pickers list everything
DD_LIST_HEIGHT = 220    # fallback height of a dropdown's scrolling list when the screen height is unknown
ALL_LIMIT = 600         # country / brand / type / level pickers load their whole list at once
MAX_RESULTS = 200       # most search results shown in Banks (keeps scrolling smooth)
FINDER_MAX = 100        # most BINs the BIN Finder returns
EXPORT_LIMIT = 2000
DEBOUNCE = 0.3          # seconds to wait after typing before searching
EXIT_WINDOW = 2.0       # second back press within this many seconds exits the app

STATUS_LABEL = {
    "live": ("Live data", GREEN),
    "cached": ("Cached data", CYAN),
    "stale": ("Cached (may be outdated)", ORANGE),
    "offline_db": ("Offline database", CYAN),
    "sample": ("Bundled sample - unverified", ORANGE),
}
TYPE_COLOR = {"CREDIT": GOLD, "DEBIT": GREEN, "PREPAID": ORANGE}
DISCLAIMER = ("Public BIN data can be incomplete or outdated. Information only - "
              "not for identity, credit or compliance decisions.")
PRACTICE = "79927398713\n79927398710\n49927398716\n49927398717\n1234567812345670\n1234567812345671"


PRESS = {"hook": None}      # set by build_app: collapses an open dropdown when something else is tapped


def _guarded(fn, closes=True):
    """Wrap a tap handler so an open dropdown collapses first (tap-outside behaviour for buttons/chips)."""
    def handler(e):
        if closes and PRESS["hook"]:
            PRESS["hook"]()
        return fn(e)
    return handler


def hard_exit():
    """Close the app process (after the screen has gone dark)."""
    os._exit(0)


# ------------------------------------------------------------------ widgets
def logo(size):
    return ft.Image(src_base64=LOGO_B64, width=size, height=size, fit=ft.ImageFit.CONTAIN)


def card(*controls, title=None, border=BORDER, pad=16, gap=10):
    kids = []
    if title:
        kids.append(ft.Text(title, size=14, color=CYAN, weight=ft.FontWeight.W_600))
    kids.extend(controls)
    return ft.Container(bgcolor=CARD_BG, border=ft.border.all(1, border), border_radius=14,
                        padding=pad, content=ft.Column(kids, spacing=gap))


def capsule(label, value, color=WHITE, expand=True):
    return ft.Container(
        expand=expand, bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=8,
        padding=ft.padding.symmetric(vertical=4, horizontal=8),
        content=ft.Column([
            ft.Text(label, size=9, color=MUTED),
            ft.Text(str(value), size=12, color=color, weight=ft.FontWeight.W_500, selectable=True),
        ], spacing=0))


def row2(a, b):
    return ft.Row([a, b], spacing=8)


def button(text, on_click, primary=False, icon=None, expand=1, color=None, pad=12, size=14, closes=True):
    fg = BG if primary else (color or CYAN)
    kids = ([ft.Icon(icon, color=fg, size=max(14, size + 2))] if icon else []) + \
           [ft.Text(text, color=fg, weight=ft.FontWeight.BOLD, size=size)]
    return ft.Container(
        content=ft.Row(kids, alignment=ft.MainAxisAlignment.CENTER, spacing=5),
        bgcolor=CYAN if primary else BOX_BG,
        border=ft.border.all(1, CYAN if primary else (color or BORDER)), border_radius=12,
        padding=ft.padding.symmetric(vertical=pad), expand=expand, on_click=_guarded(on_click, closes), ink=True)


def field(label, quiet=False, **kw):
    f = ft.TextField(label=label, border_color=BORDER, focused_border_color=CYAN,
                     border_radius=10, bgcolor=BOX_BG, color=WHITE,
                     label_style=ft.TextStyle(color=MUTED, size=12), **kw)
    if quiet:
        # Keyboard suggestions/auto-correct fight with Android's text composing (part of the old
        # "can't delete the last digit" bug). Set defensively; unknown attributes are harmless.
        for attr in ("autocorrect", "enable_suggestions"):
            try:
                setattr(f, attr, False)
            except Exception:
                pass
    return f


def chip(label, on_tap):
    return ft.Container(
        content=ft.Text(label, size=11, color=WHITE), bgcolor=BOX_BG,
        border=ft.border.all(1, BORDER), border_radius=16,
        padding=ft.padding.symmetric(vertical=4, horizontal=11), on_click=_guarded(on_tap), ink=True)


def choice_chip(label, on_tap):
    """Pill that can be highlighted (quick quantity / quick card type). Returns (control, mark(selected))."""
    txt = ft.Text(label, size=13, color=WHITE)
    box = ft.Container(content=txt, bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=18,
                       padding=ft.padding.symmetric(vertical=6, horizontal=15), on_click=_guarded(on_tap), ink=True)

    def mark(selected):
        box.bgcolor = "#0F5566" if selected else BOX_BG
        box.border = ft.border.all(1, CYAN if selected else BORDER)
        txt.color = CYAN if selected else WHITE
    return box, mark


def pill(text, color):
    return ft.Container(
        content=ft.Text(text, size=11, color=color, weight=ft.FontWeight.BOLD),
        border=ft.border.all(1, color), border_radius=14,
        padding=ft.padding.symmetric(vertical=3, horizontal=10))


def mini_icon(icon, tooltip, on_click, color=MUTED):
    return ft.IconButton(icon, icon_size=16, icon_color=color, tooltip=tooltip, on_click=on_click,
                         width=30, height=30)


def splash():
    return ft.Container(
        expand=True, bgcolor=BG, alignment=ft.alignment.center,
        content=ft.Column([
            logo(132),
            ft.Text("BIN Atlas", size=30, weight=ft.FontWeight.BOLD, color=WHITE),
            ft.Text("Issuer intelligence at a glance", size=13, color=CYAN),
            ft.Container(height=22),
            ft.ProgressBar(width=190, color=CYAN, bgcolor=BOX_BG),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER, spacing=8))


# ---------------------------------------------------------------------- app
def build_app(page: ft.Page, engine, view):
    from engine import (DATASET_CREDIT, SCHEME_DISPLAY, extract_queries, flag_emoji, luhn_batch,
                        luhn_steps)

    body = ft.Container(expand=True, padding=12)
    pickers = {}
    nav_state = {"detail_back": None, "last_back": 0.0}

    def snack(msg, color=CYAN, duration=4000):
        page.open(ft.SnackBar(ft.Text(msg, color=BG, weight=ft.FontWeight.BOLD), bgcolor=color,
                              duration=duration))

    def copy(text, msg="Copied!"):
        page.set_clipboard(text)
        snack(msg, GREEN)

    def app_header(title, subtitle, compact=False):
        return ft.Container(
            bgcolor=CARD_BG, border=ft.border.all(1, CYAN), border_radius=14,
            padding=ft.padding.only(left=10 if compact else 12, top=4 if compact else 10,
                                    bottom=4 if compact else 10, right=2 if compact else 4),
            content=ft.Row([
                logo(30 if compact else 42),
                ft.Column([ft.Text(title, size=16 if compact else 19, weight=ft.FontWeight.BOLD, color=WHITE),
                           ft.Text(subtitle, size=10 if compact else 11, color=CYAN)], spacing=0, expand=True),
                ft.IconButton(ICONS.SETTINGS, icon_color=CYAN, tooltip="API keys & sources",
                              icon_size=20 if compact else 24, on_click=lambda _: open_settings()),
            ], spacing=8 if compact else 10))

    def flag_of(r):
        return flag_emoji(r.get("country_code", ""))

    # ------------------------------------------------------- result card
    def set_card(holder, d):
        holder.content = result_card(d, holder)
        page.update()

    def result_card(d, holder):
        """One BIN card. `holder` is the Container showing it, so Save / Remove / Refresh
        and background updates can swap in a new card in place."""
        q, b = d["query"], d["bin"]
        extended = len(q) > 6
        if not d["found"]:
            guess = ("" if d["detected_scheme"] == "UNKNOWN" else
                     f"Network guessed from prefix: {d['detected_scheme']}"
                     f"{' · length ' + d['expected_length'] if d['expected_length'] else ''}")
            return card(
                ft.Text(q or b, size=20, weight=ft.FontWeight.BOLD, color=WHITE),
                ft.Text(d["message"], color=ORANGE, size=13),
                ft.Text(guess, color=MUTED, size=12, visible=bool(guess)),
                ft.Text(d.get("trail", ""), color=MUTED, size=10, visible=bool(d.get("trail"))),
                title="No issuer data", border=ORANGE)

        saved = bool(d.get("saved"))
        label, color = STATUS_LABEL.get(d["status"], ("", MUTED))
        t = d["type"]
        note_field = field("Note - saved together with this number", value=d.get("note") or "",
                           text_size=12, max_length=120, dense=True,
                           content_padding=ft.padding.symmetric(vertical=8, horizontal=10))

        def rebuild(**changes):
            nd = dict(d)
            nd.update(changes)
            holder.content = result_card(nd, holder)
            page.update()

        def do_save(_):
            if engine.save_query(q, note_field.value or ""):
                rec = engine.get_record(q)
                rebuild(saved=True, note=rec["note"], saved_at=rec["saved_at"])
                snack("Note updated." if saved else "Saved to the Saved tab.", GREEN)

        def do_remove(_):
            engine.unsave_query(q)
            rebuild(saved=False, note="")
            snack("Removed from Saved.", ORANGE)

        def do_refresh(_):
            def work():
                fresh = engine.lookup(q, allow_network=True, force_refresh=True)
                set_card(holder, fresh)
                snack(fresh["message"] or "Refreshed.", GREEN if fresh["status"] == "live" else ORANGE)
            page.run_thread(work)

        # Save / Copy / Refresh share ONE row so they are visible without scrolling.
        actions = [
            button("Update note" if saved else "Save", do_save, primary=True, expand=2, pad=8, size=12,
                   icon=ICONS.BOOKMARK if saved else ICONS.BOOKMARK_ADD),
            button("Copy", lambda _: copy(q, "Number copied"), icon=ICONS.CONTENT_COPY, pad=8, size=12),
            button("Refresh", do_refresh, icon=ICONS.REFRESH, pad=8, size=12)]
        if saved:
            actions.append(mini_icon(ICONS.DELETE_OUTLINE, "Remove from Saved", do_remove, color=RED))
        took = f" · {d['elapsed']:.1f}s" if d.get("status") == "live" and d.get("elapsed") else ""
        pills = [pill(t if t != "N/A" else "TYPE N/A", TYPE_COLOR.get(t, MUTED)), pill(label, color)]
        if d.get("refreshing"):
            pills.append(pill("Updating...", ORANGE))
        return card(
            ft.Row([
                ft.Text(d["flag"], size=34),
                ft.Column([
                    ft.Row([ft.Text(q, size=22, weight=ft.FontWeight.BOLD, color=WHITE, selectable=True),
                            mini_icon(ICONS.CONTENT_COPY, "Copy this number",
                                      lambda _: copy(q, "Number copied"), color=CYAN) if extended
                            else ft.Container(width=0)], spacing=2),
                    ft.Text(f"BIN {b}", size=10, color=MUTED, visible=extended),
                    ft.Text(f"{d['scheme']} · {t} · {d['brand']}", size=11, color=MUTED)],
                    spacing=0, expand=True),
                ft.Icon(ICONS.BOOKMARK if saved else ICONS.BOOKMARK_BORDER,
                        color=GOLD if saved else MUTED, size=22),
            ], spacing=8),
            ft.Row(pills, spacing=6, wrap=True, run_spacing=4),
            ft.Text(d["message"], size=10, color=ORANGE, visible=bool(d["message"])),
            ft.Row([capsule("Scheme", d["scheme"]), capsule("Type", t, TYPE_COLOR.get(t, WHITE)),
                    capsule("Luhn", d["luhn"])], spacing=6),
            ft.Row([capsule("Tier / level", d["brand"]), capsule("Currency", d["currency"]),
                    capsule("Typical length", d["expected_length"] or "N/A")], spacing=6),
            ft.Row([capsule("Issuer / bank", d["bank"])]),
            ft.Row([capsule("Country", f"{d['country']} ({d['country_code'] or 'N/A'}/{d['country_a3']})", expand=2),
                    capsule("Network by prefix", d["detected_scheme"])], spacing=6),
            ft.Row([
                ft.Text(f"Source: {d['source']}" + (f" · fetched {d['fetched_at'][:10]}" if d.get("fetched_at") else "")
                        + took, size=10, color=MUTED, expand=True),
                mini_icon(ICONS.DESCRIPTION, "Copy full details",
                          lambda _: copy(engine.format_entry(d, note_field.value), "Details copied")),
            ], spacing=4),
            ft.Text(d.get("trail", ""), size=9, color=MUTED, visible=bool(d.get("trail"))),
            note_field,
            ft.Row(actions, spacing=6),
            border=CYAN, pad=12, gap=6)

    def holder_for(d):
        h = ft.Container()
        h.content = result_card(d, h)
        return h

    def confirm(title, message, yes_label, no_label, on_yes):
        """Modal confirmation. The first button runs `on_yes`, the second just closes."""
        dlg = ft.AlertDialog(modal=True, bgcolor=CARD_BG,
                             title=ft.Text(title, color=WHITE, size=18, weight=ft.FontWeight.BOLD))
        if message:
            dlg.content = ft.Text(message, size=13, color=MUTED)

        def yes(_):
            page.close(dlg)
            on_yes()
        dlg.actions = [
            ft.TextButton(content=ft.Text(yes_label, color=RED, weight=ft.FontWeight.BOLD), on_click=yes),
            ft.TextButton(content=ft.Text(no_label, color=CYAN, weight=ft.FontWeight.BOLD),
                          on_click=lambda _: page.close(dlg))]
        page.open(dlg)

    def delete_bin(q, kind):
        def do():
            if kind == "saved":
                engine.unsave_query(q)
            else:
                engine.delete_search(q)
            refresh_saved()
            snack("BIN deleted.", GREEN)
        where = "Saved" if kind == "saved" else "History"
        confirm("Delete BIN \u26A0\uFE0F", f"{q} will be removed from {where}.", "YES", "NO", do)

    def tile(r, back_idx, delete=None):
        """List row for a BIN. `delete` = "saved" / "history" adds a red trash icon under the bookmark."""
        q = r.get("query") or r["bin"]
        note = (r.get("note") or "").strip()
        saved_at = (r.get("saved_at") or "")[:16]
        marker = ft.Icon(ICONS.BOOKMARK if r.get("saved") else ICONS.CHEVRON_RIGHT,
                         color=GOLD if r.get("saved") else MUTED, size=18)
        right = marker if not delete else ft.Column(
            [marker, mini_icon(ICONS.DELETE_OUTLINE, "Delete from " + delete,
                               lambda _, q=q, k=delete: delete_bin(q, k), color=RED)],
            spacing=4, alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        return ft.Container(
            bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10,
            padding=ft.padding.only(left=10, top=8, bottom=8, right=4), ink=True,
            on_click=lambda _, q=q: show_detail(q, back_idx),
            content=ft.Row([
                ft.Text(flag_of(r), size=24),
                ft.Column([
                    ft.Row([ft.Text(q, size=14, color=WHITE, weight=ft.FontWeight.BOLD),
                            mini_icon(ICONS.CONTENT_COPY, "Copy number",
                                      lambda _, q=q: copy(q, "Number copied"))], spacing=2),
                    ft.Text(f"BIN {r['bin']}", size=10, color=MUTED, visible=len(q) > 6),
                    ft.Text(f"{str(r.get('bank'))[:32]} · {r['scheme']} · {r['type']} · {r['brand']}",
                            size=11, color=MUTED),
                    ft.Text(f"\u270E {note}", size=11, color=GOLD, visible=bool(note)),
                    ft.Text(f"saved {saved_at}", size=10, color=MUTED, visible=bool(saved_at)),
                ], spacing=1, expand=True),
                right,
            ], spacing=8))

    def show_detail(q, back_idx):
        """Full card for a stored number, shown in place (no jump to the Lookup tab)."""
        holder = holder_for(engine.get_record(q))
        body.content = ft.Column([
            ft.Row([ft.IconButton(ICONS.ARROW_BACK, icon_color=CYAN, on_click=lambda _: show(back_idx)),
                    ft.Text("BIN details", size=16, color=WHITE, weight=ft.FontWeight.W_600)]),
            holder,
        ], spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)
        nav_state["detail_back"] = back_idx
        page.update()

    # ----------------------------------------------------- inline dropdown (opens under the tapped field)
    dd_slots = {}                    # field name -> container that holds its open dropdown (data = is open)
    dd_boxes = {}                    # field name -> the field box (its border lights up while open)

    def new_slot(name):
        slot = ft.Container(key=f"dd_{name}", data=False)
        try:                                                    # smooth expand / collapse, ease-in-out
            slot.animate_size = ft.Animation(220, ft.AnimationCurve.EASE_IN_OUT)
        except Exception:
            pass
        dd_slots[name] = slot
        return slot

    def set_box_active(name, active):
        box = dd_boxes.get(name)
        if box is not None:
            box.border = ft.border.all(1, CYAN if active else BORDER)

    def close_dropdowns(except_name=None):
        """Collapse every open dropdown. Returns True if one was open."""
        was_open = False
        for n, slot in dd_slots.items():
            if n != except_name and slot.data:
                slot.data, slot.content, was_open = False, None, True
                set_box_active(n, False)
        return was_open

    def press_hook():
        if close_dropdowns():
            page.update()
    PRESS["hook"] = press_hook

    def dd_list_height():
        """Medium, screen-relative height: the whole dropdown is about 45% of the screen, so it never
        reaches the phone's Home / Back buttons."""
        h = getattr(page, "height", None) or 0
        if not h:
            return DD_LIST_HEIGHT
        return int(max(150, min(340, h * 0.45 - 140)))

    def toggle_dropdown(name, title, fetch, current, on_choose, hint="", paged=False, with_all=True,
                        need_text="", host=None):
        """Dropdown that expands directly below the tapped field: search box on top, a medium-height list
        you scroll with your finger (scrollbar on the far right, rows full width), and a Close button at
        the bottom. Short lists (countries, brands, types, levels) load whole; the long BANK list is paged
        (PICK_PAGE rows + "Show more"). With `need_text` the list stays empty until the user types."""
        slot = dd_slots[name]
        if slot.data:                                      # tapping the field again collapses it
            close_dropdowns()
            page.update()
            return
        close_dropdowns(except_name=name)
        gutter = ft.margin.only(right=10)                  # clean space between the rows and the scrollbar
        search = field("Search", text_size=13, dense=True, autofocus=bool(need_text),
                       content_padding=ft.padding.symmetric(vertical=8, horizontal=10))
        listing = ft.Column(spacing=3, scroll=ft.ScrollMode.AUTO, expand=True,
                            horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
        st = {"offset": 0, "rows": [], "more": False, "timer": None}
        more_btn = ft.Container(margin=gutter, content=button(
            "Show more", lambda _: load(False), icon=ICONS.EXPAND_MORE, pad=8, size=12, closes=False))

        def choose(key, label):
            close_dropdowns()
            on_choose(key, label)

        def row(key, label):
            active = key == current
            return ft.Container(
                bgcolor=BOX_BG, border=ft.border.all(1, CYAN if active else BORDER), border_radius=8, ink=True,
                margin=gutter, alignment=ft.alignment.center_left,
                padding=ft.padding.symmetric(vertical=9, horizontal=12),
                on_click=lambda _, k=key, l=label: choose(k, l),
                content=ft.Text(label, size=13, color=CYAN if active else WHITE))

        def show_rows():
            listing.controls = st["rows"] + ([more_btn] if st["more"] else [])
            page.update()

        def load(reset=False):
            like = (search.value or "").strip()
            if reset:
                st["offset"], st["rows"] = 0, []
            if need_text and not like:                     # nothing is listed until the user types
                st["rows"], st["more"] = [ft.Text(need_text, size=12, color=MUTED)], False
                show_rows()
                return
            if reset and not like and with_all:
                st["rows"] = [row("", "All")]
            rows = fetch(like, PICK_PAGE if paged else ALL_LIMIT, st["offset"])
            st["offset"] += len(rows)
            st["rows"] = st["rows"] + [row(k, l) for k, l in rows]
            if reset and like and not rows:
                st["rows"] = [ft.Text("No matches.", size=12, color=MUTED)]
            st["more"] = paged and len(rows) == PICK_PAGE
            show_rows()

        def on_type(_):
            if st["timer"]:
                st["timer"].cancel()
            if DEBOUNCE <= 0:
                load(True)
                return
            st["timer"] = threading.Timer(DEBOUNCE, lambda: load(True))
            st["timer"].daemon = True
            st["timer"].start()

        def close(_=None):
            close_dropdowns()
            page.update()

        try:                                               # soft shadow lifts the open dropdown off the page
            shadow = ft.BoxShadow(spread_radius=0, blur_radius=14, color="#66000000", offset=ft.Offset(0, 3))
        except Exception:
            shadow = None
        search.on_change = on_type
        panel = ft.Container(
            margin=ft.margin.only(top=6), padding=8, bgcolor="#0B2636", border_radius=10,
            border=ft.border.all(1, CYAN), shadow=shadow,
            content=ft.Column([
                ft.Text(title, size=12, color=CYAN, weight=ft.FontWeight.W_600),
                ft.Text(hint, size=11, color=MUTED, visible=bool(hint)),
                search,
                ft.Container(height=dd_list_height(), content=listing),
                ft.Row([ft.Container(expand=True),
                        ft.TextButton(content=ft.Text("Close", color=CYAN, weight=ft.FontWeight.BOLD),
                                      on_click=close)]),
            ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.STRETCH))
        slot.content = ft.GestureDetector(content=panel, on_tap=lambda e: None)   # taps inside don't count as "outside"
        slot.data = True
        set_box_active(name, True)
        load(True)
        try:                                               # bring the dropdown into view
            host().scroll_to(key=slot.key, duration=250)
        except Exception:
            pass

    # ----------------------------------------------------- storage permission pop-up
    def storage_granted():
        """True when the app can write to shared storage. Desktop: always True. Never raises."""
        try:
            if android_storage.has_all_files_access():
                return True
            return engine.export_folder()[1]            # some phones allow the folder without the special access
        except Exception:
            return True

    def open_access_screen(_=None):
        if not android_storage.open_access_settings():
            snack("Open Android Settings > Apps > BIN Atlas > Permissions > Files and media, "
                  "then allow access to all files.", ORANGE, duration=10000)

    def ask_storage(then=None):
        """'Permission Required' pop-up. ALLOW opens Android's "All files access" screen; the red X closes
        the pop-up and carries on (then = the export/import the user asked for)."""
        dlg = ft.AlertDialog(modal=True, bgcolor=WHITE)
        dark = "#2B3A4A"

        def close():
            page.close(dlg)

        def dismiss(_):
            close()
            if then:
                then()

        def allow(_):
            close()
            open_access_screen()

        dlg.content = ft.Container(width=300, content=ft.Column([
            ft.Row([ft.Container(expand=True),
                    ft.Container(width=40, height=40, border_radius=20, bgcolor=CYAN, ink=True,
                                 alignment=ft.alignment.center, on_click=dismiss,
                                 content=ft.Icon(ICONS.CLOSE, color=BG, size=22))]),
            ft.Icon(ICONS.FOLDER, color="#4A7BFF", size=64),
            ft.Text("Permission Required", size=22, color=dark, text_align=ft.TextAlign.CENTER),
            ft.Text("To save and load your files (TXT exports and BIN lists), please allow BIN Atlas to "
                    "access all your files.", size=14, color=dark, text_align=ft.TextAlign.CENTER),
            ft.Container(bgcolor=CYAN, border_radius=16, ink=True, on_click=allow,
                         padding=ft.padding.symmetric(vertical=14), alignment=ft.alignment.center,
                         content=ft.Text("ALLOW", size=18, color=BG, weight=ft.FontWeight.BOLD)),
        ], spacing=10, tight=True, horizontal_alignment=ft.CrossAxisAlignment.CENTER))
        try:
            dlg.shape = ft.RoundedRectangleBorder(radius=26)     # rounded card like the example
        except Exception:
            pass
        page.open(dlg)

    def with_storage(action):
        """Run an export/import. Without access the pop-up shows first, every time, until it is granted."""
        if storage_granted():
            action()
        else:
            ask_storage(then=action)

    # ----------------------------------------------------- files / export
    def on_saved_file(e):
        path = getattr(e, "path", None)
        if path:
            snack(f"File saved: {path}", GREEN)

    def save_picker():
        if "save" not in pickers:
            pickers["save"] = ft.FilePicker(on_result=on_saved_file)
            page.overlay.append(pickers["save"])
            page.update()
        return pickers["save"]

    def export_txt(rows, prefix):
        if not rows:
            snack("Nothing to export yet.", ORANGE)
            return
        with_storage(lambda: export_now(rows, prefix))

    def export_now(rows, prefix, base_name=None):
        """Write the TXT into /storage/emulated/0/BIN ATLAS when Android allows it; otherwise the next
        visible folder, and as a last resort the app folder plus a "save as" picker."""
        text = engine.format_export(rows)
        page.set_clipboard(text)                       # always available as a fallback
        try:
            path, name, preferred = engine.export_text_file(text, prefix, base_name)
        except Exception as exc:
            snack(f"Could not write the file: {exc}", RED, duration=8000)
            return
        if preferred:
            snack(f"Saved {len(rows)} entries to {path}", GREEN, duration=7000)
        elif not engine.is_app_private(path):
            snack(f"Saved to {path}. To use {engine.export_dirs[0]}, allow \"All files access\" for BIN ATLAS "
                  f"in Android Settings (see the gear icon > Storage).", ORANGE, duration=10000)
        else:
            try:
                save_picker().save_file(dialog_title="Save TXT file", file_name=name,
                                        allowed_extensions=["txt"], src_bytes=text.encode("utf-8"))
                snack(f"Pick where to save the file. Copied to the clipboard too. "
                      f"(For {engine.export_dirs[0]}: see gear icon > Storage.)", ORANGE, duration=9000)
            except Exception:
                snack(f"Copied to the clipboard. File: {path}. For {engine.export_dirs[0]}, "
                      f"see gear icon > Storage.", ORANGE, duration=10000)

    # ------------------------------------------------------- settings
    def open_settings():
        k_handy = field("HandyAPI key (publishable, starts with PUB-)", value=engine.get_setting("handyapi_key"),
                        password=True, can_reveal_password=True, text_size=13)
        k_bl = field("binlist.io key (starts with bl_)", value=engine.get_setting("binlistio_key"),
                     password=True, can_reveal_password=True, text_size=13)
        combine = ft.Switch(label="Combine sources for fuller data", value=engine.get_setting("combine", "1") == "1",
                            active_color=CYAN, label_style=ft.TextStyle(size=12, color=MUTED))
        status = ft.Column(spacing=2)
        storage_text = ft.Text("", size=11, color=MUTED)

        def check_storage(_=None, refresh=True):
            folder, preferred = engine.export_folder()
            if preferred:
                storage_text.value, storage_text.color = f"\u2713 TXT files are saved to: {folder}", GREEN
            else:
                storage_text.value = (
                    f"\u26A0 Android has not allowed writing to {engine.export_dirs[0]} yet, so files go to:\n{folder}\n\n"
                    "Tap Allow access, switch on \"Allow access to manage all files\", come back and tap "
                    "Check storage.")
                storage_text.color = ORANGE
            if refresh:
                page.update()
        check_storage(refresh=False)

        def save(_=None):
            problems = engine.set_api_keys(k_handy.value or "", k_bl.value or "")
            if problems:
                status.controls = [ft.Text(p, size=12, color=RED) for p in problems]
                page.update()
                return False
            engine.set_setting("combine", "1" if combine.value else "0")
            refresh_banner()
            return True

        def save_and_test(_):
            if not save():
                return
            status.controls = [ft.Text("Testing sources...", size=12, color=MUTED)]
            page.update()

            def work():
                res = engine.test_providers()
                status.controls = [
                    ft.Text(f"{'✓' if ok else '✗'}  {name}: {msg}", size=12, color=GREEN if ok else ORANGE)
                    for name, (ok, msg) in res.items()]
                page.update()
            page.run_thread(work)

        dlg = ft.AlertDialog(
            modal=True, bgcolor=CARD_BG,
            title=ft.Text("API keys & sources", color=WHITE, size=18),
            content=ft.Container(width=330, content=ft.Column([
                ft.Text("Lookups try binlist.io, then HandyAPI, then binlist.net, and switch "
                        "automatically if one is slow or fails. Keys stay on this device only.",
                        size=12, color=MUTED),
                k_bl, k_handy, combine, status,
                ft.Text("Use only the publishable PUB- key here. Never put a secret (HAS-) key in a mobile app.",
                        size=11, color=ORANGE),
                ft.Text("Storage", size=13, color=CYAN, weight=ft.FontWeight.W_600),
                storage_text,
                ft.Row([button("Allow access", open_access_screen, icon=ICONS.LOCK_OPEN, pad=9, size=12),
                        button("Check storage", check_storage, icon=ICONS.FOLDER_OPEN, pad=9, size=12)],
                       spacing=8),
                ft.Text(DATASET_CREDIT, size=10, color=MUTED),
            ], spacing=10, tight=True, scroll=ft.ScrollMode.AUTO)),
            actions=[ft.TextButton("Close", on_click=lambda _: page.close(dlg)),
                     ft.TextButton("Save", on_click=lambda _: (save() and snack("Saved.", GREEN))),
                     ft.TextButton("Save & test", on_click=save_and_test)],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dlg)

    # ========================================================== LOOKUP
    bin_input = field("BIN - first 6 to 8 digits (separate several with commas)", value="",
                      quiet=True, max_length=300, on_submit=lambda e: run_lookup(), text_size=14,
                      dense=True, content_padding=ft.padding.symmetric(vertical=8, horizontal=10),
                      helper_text="Up to 8 digits are used (the BIN/IIN). Extra digits are ignored.",
                      helper_style=ft.TextStyle(color=MUTED, size=10))
    offline_switch = ft.Switch(label="Offline mode (local data only)", value=False, active_color=CYAN,
                               label_style=ft.TextStyle(size=12, color=MUTED))
    progress = ft.ProgressBar(color=CYAN, bgcolor=BOX_BG, visible=False)
    results_col = ft.Column(spacing=8)
    recent_row = ft.Row(spacing=6, wrap=True, run_spacing=6)
    key_banner = ft.Container(
        bgcolor="#2A1E05", border=ft.border.all(1, ORANGE), border_radius=10, padding=8, ink=True,
        on_click=lambda _: open_settings(),
        content=ft.Row([ft.Icon(ICONS.KEY, color=ORANGE, size=16),
                        ft.Text("Add your free API keys (tap here) so lookups keep working when a source is busy.",
                                size=11, color=WHITE, expand=True)], spacing=8))

    def refresh_banner():
        key_banner.visible = not engine.has_keys()

    def refresh_recent():
        recent_row.controls = [chip(h["query"], lambda _, q=h["query"]: quick(q)) for h in engine.history(5)]

    def quick(q):
        bin_input.value = q
        run_lookup()

    def placeholder(q):
        return card(ft.Row([ft.ProgressRing(width=18, height=18, stroke_width=2, color=CYAN),
                            ft.Text(f"Looking up {q}...", size=13, color=MUTED)], spacing=10))

    def run_lookup(_=None):
        queries = extract_queries(bin_input.value or "")
        if not queries:
            snack("Enter at least 6 digits of a BIN.", ORANGE)
            return
        offline = offline_switch.value
        holders = [(q, ft.Container(content=placeholder(q))) for q in queries]
        results_col.controls = [h for _, h in holders]
        progress.visible = True
        page.update()

        def one(q, h):
            try:
                # Cached/offline rows answer instantly and upgrade in the background (on_update).
                d = engine.lookup(q, allow_network=not offline, on_update=lambda r, h=h: set_card(h, r))
                set_card(h, d)
            except Exception as exc:
                h.content = card(ft.Text(f"Lookup failed: {exc}", color=RED, size=13), border=RED)
                page.update()

        def coordinate():
            try:
                with ThreadPoolExecutor(max_workers=4) as pool:      # several BINs resolve in parallel
                    for f in [pool.submit(one, q, h) for q, h in holders]:
                        f.result()
                if len(queries) > 1:
                    results_col.controls.append(
                        button("Copy all numbers", lambda _: copy("\n".join(queries), "Numbers copied"),
                               icon=ICONS.CONTENT_COPY))
                refresh_recent()
            finally:
                progress.visible = False
                page.update()
        page.run_thread(coordinate)

    refresh_recent()
    refresh_banner()
    lookup_view = ft.Column([
        app_header("BIN Atlas", "Issuer, network, country and card type from a BIN", compact=True),
        key_banner,
        card(bin_input, offline_switch,
             ft.Text("Official test BINs", size=11, color=MUTED),
             ft.Row([chip("Visa 424242", lambda _: quick("424242")),
                     chip("MC 510510", lambda _: quick("510510")),
                     chip("Amex 378282", lambda _: quick("378282"))], spacing=6, wrap=True),
             ft.Text("Recent", size=11, color=MUTED), recent_row,
             ft.Row([button("Clear", lambda _: (setattr(bin_input, "value", ""), page.update()), pad=9, size=13),
                     button("Look up", run_lookup, primary=True, icon=ICONS.SEARCH, expand=2, pad=9, size=13)],
                    spacing=8),
             title="Input", pad=12, gap=6),
        progress, results_col,
        ft.Text(DISCLAIMER, size=9, color=MUTED, text_align=ft.TextAlign.CENTER),
    ], spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)

    # =========================================================== BANKS
    # bincheck.io-style filters: Country > Brand > Bank > Type > Level. Each opens a searchable,
    # paged list; choosing one clears the filters to its right.
    ORDER = ["country", "scheme", "bank", "type", "level"]
    TITLES = {"country": "Country", "scheme": "Brand", "bank": "Bank", "type": "Type", "level": "Level"}
    pick_state = {n: ("", "") for n in ORDER}          # name -> (key, label)
    pick_text = {}
    s_list = ft.Column(spacing=6)
    s_count = ft.Text("", size=12, color=MUTED)
    s_more = ft.Container(visible=False)
    s_state = {"filters": ("", "", "", "", ""), "total": 0, "shown": 0}
    db_text = ft.Text("", size=13, color=WHITE, weight=ft.FontWeight.W_600)
    db_status = ft.Text("", size=12, color=MUTED)
    db_progress = ft.ProgressBar(color=CYAN, bgcolor=BOX_BG, visible=False)
    db_hint = ft.Container(
        bgcolor="#2A1E05", border=ft.border.all(1, ORANGE), border_radius=12, padding=12, visible=False,
        content=ft.Text("Only a few BINs are on this device, so few countries and banks are listed. "
                        "Tap \"Download BIN database\" below to load all countries, banks and card types.",
                        size=12, color=WHITE))

    def selection(name):
        return pick_state[name][0]

    def set_pick(name, key, label):
        pick_state[name] = (key, label)
        pick_text[name].value = label or "All"
        pick_text[name].color = WHITE if key else MUTED

    def on_pick(name, key, label):
        set_pick(name, key, label)
        for n in ORDER[ORDER.index(name) + 1:]:        # changing a filter clears the ones to its right
            set_pick(n, "", "")
        page.update()

    def fetch_options(name):
        def fetch(like, limit, offset):
            rows = engine.options(name, country=selection("country"), scheme=selection("scheme"),
                                  bank=selection("bank"), type_=selection("type"),
                                  like=like, limit=limit, offset=offset)
            if name == "country":
                return [(cc, f"{flag_emoji(cc)} {n.title()} ({cc})") for cc, n in rows]
            return rows
        return fetch

    def pick_hint(name):
        """Bank list: with a country chosen only ITS banks are listed; without one, nothing is listed
        until the user types part of a bank name (then banks of all countries match)."""
        if name != "bank":
            return ""
        country = pick_state["country"][1]
        if country:
            return f"Banks in {country}. Type below to narrow the list."
        return ""

    def open_field(name):
        need = ""
        if name == "bank" and not selection("country"):
            need = "Choose a country above to list its banks, or type a bank name to search all countries."
        toggle_dropdown(name, TITLES[name], fetch_options(name), selection(name),
                        lambda k, l: on_pick(name, k, l), hint=pick_hint(name), paged=(name == "bank"),
                        need_text=need, host=lambda: search_view)

    def pick_box(name):
        txt = ft.Text("All", size=13, color=MUTED, expand=True, no_wrap=True,
                      overflow=ft.TextOverflow.ELLIPSIS)
        pick_text[name] = txt
        return ft.Container(
            expand=True, bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10, ink=True,
            padding=ft.padding.symmetric(vertical=8, horizontal=10),
            on_click=lambda _: open_field(name),
            content=ft.Column([ft.Text(TITLES[name], size=10, color=MUTED),
                               ft.Row([txt, ft.Icon(ICONS.ARROW_DROP_DOWN, color=MUTED, size=20)], spacing=4)],
                              spacing=2))

    boxes = {n: pick_box(n) for n in ORDER}
    dd_boxes.update(boxes)
    slots = {n: new_slot(n) for n in ORDER}

    def refresh_db_card():
        n = engine.count()
        db_text.value = f"{n:,} BINs on this device"
        db_hint.visible = n < 5000

    def load_more(_=None):
        room = MAX_RESULTS - s_state["shown"]
        rows = engine.search_filters(*s_state["filters"], limit=min(PAGE_SIZE, room), offset=s_state["shown"]) \
            if room > 0 else []
        s_state["shown"] += len(rows)
        s_list.controls += [tile(r, 1) for r in rows]
        capped = s_state["shown"] >= MAX_RESULTS and s_state["total"] > MAX_RESULTS
        s_more.visible = s_state["shown"] < min(s_state["total"], MAX_RESULTS)
        if not s_state["total"]:
            s_count.value = ""
        elif capped:
            s_count.value = (f"{s_state['total']:,} BIN(s) match · showing the first {MAX_RESULTS}. "
                             "Choose more filters to narrow the list.")
        else:
            s_count.value = f"{s_state['total']:,} BIN(s) found · showing {s_state['shown']:,}"
        page.update()

    def do_search(_=None):
        f = tuple(selection(n) for n in ORDER)
        if not any(f):                                  # no filter chosen: never list random BINs
            snack("Please Select One Section At Least", ORANGE)
            return
        s_state.update(filters=f, total=engine.count_filters(*f), shown=0)
        s_list.controls = []
        if not s_state["total"]:
            s_list.controls = [ft.Text("No BINs match. Download the BIN database below, or look up more BINs.",
                                       color=ORANGE, size=12)]
            s_count.value, s_more.visible = "", False
            page.update()
            return
        load_more()

    s_more.content = button("Show more", load_more, icon=ICONS.EXPAND_MORE)

    def do_reset(_=None):
        close_dropdowns()
        for n in ORDER:
            set_pick(n, "", "")
        s_list.controls, s_count.value, s_more.visible = [], "", False
        s_state.update(filters=("", "", "", "", ""), total=0, shown=0)
        page.update()

    for n in ORDER:
        set_pick(n, "", "")

    def export_results(_):
        if not any(s_state["filters"]):
            snack("Please Select One Section At Least", ORANGE)
            return
        rows = engine.search_filters(*s_state["filters"], limit=EXPORT_LIMIT)
        export_txt(rows, "bin_atlas_banks")

    def busy(on, text=""):
        db_progress.visible = on
        db_status.value = text
        page.update()

    def download_db(_):
        busy(True, "Starting download...")

        def work():
            try:
                r = engine.download_dataset(progress=lambda m: busy(True, m))
                snack(f"Done: {r['added']:,} new BINs added.", GREEN)
            except Exception as exc:
                snack(str(exc), RED)
            finally:
                busy(False)
                refresh_db_card()
                page.update()
        page.run_thread(work)

    def on_csv_picked(e):
        if not e.files:
            return
        path = e.files[0].path
        if not path:
            snack("Could not read that file's path on this device.", RED)
            return
        busy(True, "Importing...")

        def work():
            try:
                r = engine.import_csv(path, progress=lambda m: busy(True, m))
                snack(f"Imported {r['added']:,} new BINs ({r['rows']:,} rows read).", GREEN)
            except Exception as exc:
                snack(f"Import failed: {exc}", RED)
            finally:
                busy(False)
                refresh_db_card()
                page.update()
        page.run_thread(work)

    def import_csv(_):
        with_storage(open_csv_picker)

    def open_csv_picker():
        if "open" not in pickers:
            pickers["open"] = ft.FilePicker(on_result=on_csv_picked)
            page.overlay.append(pickers["open"])
            page.update()
        pickers["open"].pick_files(dialog_title="Choose a BIN list (CSV)", allow_multiple=False,
                                   file_type=ft.FilePickerFileType.CUSTOM, allowed_extensions=["csv"])

    search_view = ft.Column([
        app_header("Banks & Issuers", "Filter countries, banks, card types and levels"),
        db_hint,
        card(ft.Column([row2(boxes["country"], boxes["scheme"]), slots["country"], slots["scheme"]], spacing=0),
             ft.Column([ft.Row([boxes["bank"]]), slots["bank"]], spacing=0),
             ft.Column([row2(boxes["type"], boxes["level"]), slots["type"], slots["level"]], spacing=0),
             ft.Row([button("Search", do_search, primary=True, icon=ICONS.SEARCH),
                     button("Reset", do_reset, icon=ICONS.RESTART_ALT, color=RED)], spacing=10),
             ft.Row([button("Export TXT", export_results, icon=ICONS.DOWNLOAD)])),
        s_count, s_list, s_more,
        card(db_text, db_status, db_progress,
             ft.Text("Download once (needs internet) to unlock every country and bank offline. "
                     "You can also import your own CSV list.", size=12, color=MUTED),
             ft.Row([button("Download BIN database", download_db, primary=True, icon=ICONS.CLOUD_DOWNLOAD)]),
             ft.Row([button("Import CSV file", import_csv, icon=ICONS.UPLOAD_FILE)]),
             ft.Text(DATASET_CREDIT, size=10, color=MUTED), title="Offline BIN database"),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ================================================================= BIN FINDER
    QUICK_COUNTS = (10, 25, 50, 100)
    QUICK_TYPES = (("Visa", "VISA"), ("Mastercard", "MASTERCARD"), ("Amex", "AMEX"), ("Mix", "MIX"))
    find_state = {"type": "", "label": "", "country": "", "country_label": "All"}   # type: network, "MIX" or ""
    f_count = field("How many BINs?", value="25", text_size=14, dense=True, max_length=3,
                    keyboard_type=ft.KeyboardType.NUMBER, on_focus=lambda e: press_hook(),
                    content_padding=ft.padding.symmetric(vertical=8, horizontal=10))
    f_progress = ft.ProgressBar(color=CYAN, bgcolor=BOX_BG, visible=False)
    f_summary = ft.Text("", size=12, color=MUTED)
    f_results = ft.Column(spacing=6)
    f_hint = ft.Text("Tip: download the BIN database in the Banks tab to find BINs from every country.",
                     size=11, color=ORANGE, visible=False)
    f_type_text = ft.Text("Select card type", size=14, color=MUTED, expand=True)
    f_country_text = ft.Text("All", size=14, color=WHITE, expand=True, no_wrap=True,
                             overflow=ft.TextOverflow.ELLIPSIS)
    qty_marks, type_marks = {}, {}

    def type_label(key):
        return "Mix (all types)" if key == "MIX" else SCHEME_DISPLAY.get(key, key)

    def parse_count():
        digits = "".join(ch for ch in (f_count.value or "") if ch.isdigit())
        return int(digits) if digits else 0

    def sync_qty(_=None, update=True):
        c = parse_count()
        for n, mark in qty_marks.items():
            mark(c == n)
        if update:
            page.update()

    def set_count(n):
        f_count.value = str(n)
        sync_qty()

    def set_type(key, label, update=True):
        close_dropdowns()
        find_state.update(type=key, label=label)
        f_type_text.value = label or "Select card type"
        f_type_text.color = WHITE if key else MUTED
        for k, mark in type_marks.items():
            mark(k == key)
        if update:
            page.update()

    def set_country(key, label, update=True):
        close_dropdowns()
        find_state.update(country=key, country_label=label or "All")
        f_country_text.value = label or "All"
        if update:
            page.update()

    def country_choices(like, limit, offset):
        rows = engine.options("country", like=like, limit=limit, offset=offset)
        return [(cc, f"{flag_emoji(cc)} {n.title()} ({cc})") for cc, n in rows]

    def type_choices(like, limit, offset):
        items = [("MIX", type_label("MIX"))] + [(s, type_label(s)) for s in engine.schemes_available()]
        if like:
            items = [(k, l) for k, l in items if like.upper() in l.upper()]
        return items[offset:offset + limit]

    f_count.on_change = sync_qty
    qty_boxes, type_boxes = [], []
    for n in QUICK_COUNTS:
        box, mark = choice_chip(str(n), lambda _, n=n: set_count(n))
        qty_boxes.append(box)
        qty_marks[n] = mark
    for label, key in QUICK_TYPES:
        box, mark = choice_chip(label, lambda _, k=key: set_type(k, type_label(k)))
        type_boxes.append(box)
        type_marks[key] = mark
    sync_qty(update=False)
    set_type("", "", update=False)                    # nothing chosen until the user picks a type

    def run_finder(_=None):
        if not find_state["type"]:
            snack("Select Type Card First", ORANGE)
            return
        count = parse_count()
        if count < 1:
            snack("Enter how many BINs you want (1 to %d)." % FINDER_MAX, ORANGE)
            return
        if count > FINDER_MAX:
            count = FINDER_MAX
            f_count.value = str(count)
            sync_qty(update=False)
            snack("The maximum is %d BINs." % FINDER_MAX, ORANGE)
        schemes = None if find_state["type"] == "MIX" else [find_state["type"]]
        country, country_label = find_state["country"], find_state["country_label"]
        f_progress.visible = True
        page.update()

        def work():
            try:
                rows = engine.find_bins(schemes, count, country=country)
            except Exception as exc:
                rows = []
                snack(f"Search failed: {exc}", RED)
            finally:
                f_progress.visible = False
            f_results.controls = [tile(r, 2) for r in rows]
            countries = len({r["country_code"] for r in rows})
            if rows:
                where = country_label if country else f"{countries} countr{'y' if countries == 1 else 'ies'}"
                f_summary.value = (f"{len(rows)} BIN(s) from {where}"
                                   + (f" - only {len(rows)} match" if len(rows) < count else ""))
            else:
                f_summary.value = ("No BINs found for this type. Download the BIN database in the Banks tab "
                                   "first.")
            page.update()
        page.run_thread(work)

    def reset_finder(_=None):
        f_count.value = "25"
        sync_qty(update=False)
        set_type("", "", update=False)
        set_country("", "All", update=False)
        f_results.controls, f_summary.value = [], ""
        page.update()

    country_slot = new_slot("fcountry")
    country_box = ft.Container(
        bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10, ink=True,
        padding=ft.padding.symmetric(vertical=6, horizontal=10),
        on_click=lambda _: toggle_dropdown(
            "fcountry", "Country", country_choices, find_state["country"], set_country,
            hint="All = BINs from different countries. Pick one country for BINs only from it.",
            host=lambda: finder_view),
        content=ft.Column([ft.Text("Country", size=10, color=MUTED),
                           ft.Row([f_country_text, ft.Icon(ICONS.ARROW_DROP_DOWN, color=MUTED, size=20)], spacing=4)],
                          spacing=0))
    type_slot = new_slot("ftype")
    type_box = ft.Container(
        bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10, ink=True,
        padding=ft.padding.symmetric(vertical=6, horizontal=10),
        on_click=lambda _: toggle_dropdown("ftype", "Select Card Type", type_choices, find_state["type"],
                                           set_type, with_all=False, host=lambda: finder_view),
        content=ft.Column([ft.Text("Select Card Type", size=10, color=MUTED),
                           ft.Row([f_type_text, ft.Icon(ICONS.ARROW_DROP_DOWN, color=MUTED, size=20)], spacing=4)],
                          spacing=0))

    dd_boxes["fcountry"], dd_boxes["ftype"] = country_box, type_box
    finder_view = ft.Column([
        app_header("BIN Finder", "Find BINs from different countries"),
        card(f_count,
             ft.Text("Quick quantity", size=11, color=CYAN),
             ft.Row(qty_boxes, spacing=8, wrap=True, run_spacing=6),
             ft.Column([country_box, country_slot], spacing=0),
             ft.Column([type_box, type_slot], spacing=0),
             ft.Text("Quick card type", size=11, color=CYAN),
             ft.Row(type_boxes, spacing=8, wrap=True, run_spacing=6),
             ft.Row([button("Clear", reset_finder, pad=9, size=13),
                     button("Find BINs", run_finder, primary=True, icon=ICONS.EXPLORE, expand=2, pad=9, size=13)],
                    spacing=8),
             title="Input", pad=12, gap=8),
        f_hint, f_progress, f_summary, f_results,
        ft.Text("BINs are picked at random from the offline database: with All, from different countries (at most "
                "3 per country); with a country chosen, only from that country. Tap one to see its details, "
                "add a note and save it.", size=10, color=MUTED),
    ], spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)

    # ============================================== LEARN (Luhn checker)
    luhn_input = field("Numbers to check - one per line or separated by commas (max 25)",
                       value=PRACTICE, quiet=True, multiline=True, min_lines=4, max_lines=8, text_size=13)
    luhn_out = ft.Column(spacing=8)

    def steps_view(item):
        res = luhn_steps(item["digits"])
        boxes = [ft.Container(
            width=36, padding=3, border_radius=8,
            bgcolor="#103342" if s["doubled"] else BOX_BG,
            border=ft.border.all(1, CYAN if s["doubled"] else BORDER),
            content=ft.Column([
                ft.Text(str(s["digit"]), size=15, weight=ft.FontWeight.BOLD, color=WHITE),
                ft.Text(f"x2→{s['value']}" if s["doubled"] else str(s["value"]), size=9,
                        color=CYAN if s["doubled"] else MUTED)],
                spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER)) for s in res["steps"]]
        ok = res["valid"]
        return ft.Column([
            ft.Row(boxes, wrap=True, spacing=3, run_spacing=3),
            ft.Text("Highlighted digits are doubled (every 2nd digit from the right); a doubled value above 9 "
                    "has 9 subtracted.", size=10, color=MUTED),
            ft.Text(f"Sum = {res['total']}  →  {'divisible by 10: PASSES' if ok else 'not divisible by 10: FAILS'}",
                    size=12, weight=ft.FontWeight.BOLD, color=GREEN if ok else RED)], spacing=6)

    def luhn_row(item):
        detail = ft.Container(visible=False, padding=ft.padding.only(top=6))
        if item["valid"] is None:
            verdict, vcolor = item["error"] or "n/a", ORANGE
        else:
            verdict, vcolor = ("PASS", GREEN) if item["valid"] else ("FAIL", RED)
        extra = f"{item['length']} digits"
        if item["scheme"] != "UNKNOWN":
            extra += f" · {item['scheme']}" + ("" if item["length_ok"] is not False else " · unusual length")

        def toggle(_):
            if item["valid"] is None:
                return
            if not detail.content:
                detail.content = steps_view(item)
            detail.visible = not detail.visible
            page.update()
        return ft.Container(
            bgcolor=BOX_BG, border=ft.border.all(1, BORDER), border_radius=10, padding=10, ink=True,
            on_click=toggle,
            content=ft.Column([
                ft.Row([ft.Text(f"{item['index']}.", size=12, color=MUTED),
                        ft.Column([ft.Text(item["masked"], size=14, color=WHITE, weight=ft.FontWeight.W_600,
                                           selectable=True), ft.Text(extra, size=11, color=MUTED)],
                                  spacing=1, expand=True),
                        pill(verdict, vcolor)], spacing=10),
                detail], spacing=0))

    def run_luhn(_=None):
        res = luhn_batch(luhn_input.value or "")
        if not res["items"]:
            luhn_out.controls = [ft.Text("Enter at least one number.", color=ORANGE, size=12)]
        else:
            luhn_out.controls = (
                [ft.Text(f"{res['passed']} pass · {res['failed']} fail" +
                         (" · only the first 25 were checked" if res["truncated"] else "") +
                         "  (tap a row for the step-by-step)", size=12, color=CYAN)]
                + [luhn_row(i) for i in res["items"]])
        page.update()

    luhn_view = ft.Column([
        app_header("Learn · Luhn checker", "Practice the checksum behind card numbers"),
        card(luhn_input,
             ft.Row([button("Practice set", lambda _: (setattr(luhn_input, "value", PRACTICE), run_luhn())),
                     button("Clear", lambda _: (setattr(luhn_input, "value", ""),
                                                setattr(luhn_out, "controls", []), page.update()))], spacing=8),
             button("Check all", run_luhn, primary=True, icon=ICONS.FACT_CHECK),
             ft.Text("Runs on your device only. Nothing is sent or stored. Long numbers are shown masked.",
                     size=10, color=MUTED), title="Luhn checker (multiple numbers)"),
        luhn_out,
        card(ft.Text("• First digit: Major Industry Identifier (4 Visa, 5/2 Mastercard, 3 Amex/JCB...)\n"
                     "• First 6-8 digits: the BIN / IIN - identifies the issuing bank and product\n"
                     "• Middle digits: the account identifier\n"
                     "• Last digit: a Luhn check digit that catches typing mistakes",
                     size=12, color=WHITE),
             ft.Text("Passing Luhn only means the digits are consistent. It does not mean a card exists "
                     "or is active.", size=11, color=MUTED), title="Anatomy of a card number"),
    ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)

    # ============================================================ SAVED
    saved_q = field("Search saved by number, bank, country or note", text_size=13)
    saved_list, hist_list = ft.Column(spacing=6), ft.Column(spacing=6)
    saved_title = ft.Text("", size=14, color=CYAN, weight=ft.FontWeight.W_600)
    hist_title = ft.Text("", size=14, color=CYAN, weight=ft.FontWeight.W_600)

    def refresh_saved(_=None):
        favs = engine.saved(saved_q.value or "", limit=100)
        hist = engine.history(30)
        saved_title.value = f"Saved ({engine.saved_count()})"
        saved_list.controls = [tile(r, 4, "saved") for r in favs] or [
            ft.Text("Nothing here yet. Look up a BIN, add a note and tap Save." if not saved_q.value
                    else "No saved BIN matches that search.", size=12, color=MUTED)]
        hist_title.value = f"History ({len(hist)})"
        hist_list.controls = [tile(r, 4, "history") for r in hist] or [
            ft.Text("No lookups yet.", size=12, color=MUTED)]
        page.update()

    def ask_replace(name, base, typed_text, rows, prefix):
        """Second, small modal: a file with that name is already in the destination folder."""
        dlg = ft.AlertDialog(modal=True, bgcolor=CARD_BG)

        def replace(_):
            page.close(dlg)
            export_now(rows, prefix, base)              # overwrites the old file, same folder logic as ever

        def edit_name(_):
            page.close(dlg)
            ask_export_name(rows, prefix, typed_text)   # back to the first modal, previous text kept

        dlg.content = ft.Container(width=280, content=ft.Column([
            ft.Text("This name already exists", size=15, color=ORANGE, weight=ft.FontWeight.W_600),
            ft.Text(name, size=12, color=MUTED)], spacing=4, tight=True))
        dlg.actions = [
            ft.TextButton(content=ft.Text("REPLACE", color=ORANGE, weight=ft.FontWeight.BOLD), on_click=replace),
            ft.TextButton(content=ft.Text("EDIT NAME", color=CYAN, weight=ft.FontWeight.BOLD), on_click=edit_name)]
        page.open(dlg)

    def ask_export_name(rows, prefix, initial=""):
        """First modal: the user types the file name (".txt" is added automatically). The keyboard opens at once."""
        name_field = field("File name", value=initial, text_size=14, autofocus=True, dense=True, max_length=100,
                           hint_text="e.g. my_saved_bins",
                           content_padding=ft.padding.symmetric(vertical=10, horizontal=10))
        error = ft.Text("Please enter name to save", size=12, color=ORANGE, visible=False)
        dlg = ft.AlertDialog(modal=True, bgcolor=CARD_BG,
                             title=ft.Text("Export TXT", color=WHITE, size=18, weight=ft.FontWeight.BOLD))

        def save(_=None):
            base = engine.clean_filename(name_field.value or "")
            if not base:                                # needs at least one letter or number
                error.visible = True
                page.update()
                return
            _, name, _, exists = engine.export_path(base)   # look in the real destination folder first
            page.close(dlg)
            if exists:
                ask_replace(name, base, name_field.value or "", rows, prefix)
            else:
                export_now(rows, prefix, base)

        def typed(_):
            if error.visible:
                error.visible = False
                page.update()

        name_field.on_change = typed
        name_field.on_submit = save                     # the keyboard's "done" key saves too
        dlg.content = ft.Container(width=300, content=ft.Column([
            ft.Text("Choose a name for the file. The .txt extension is added automatically.", size=12, color=MUTED),
            name_field, error], spacing=8, tight=True))
        dlg.actions = [
            ft.TextButton(content=ft.Text("CANCEL", color=MUTED, weight=ft.FontWeight.BOLD),
                          on_click=lambda _: page.close(dlg)),
            ft.TextButton(content=ft.Text("SAVE", color=CYAN, weight=ft.FontWeight.BOLD), on_click=save)]
        page.open(dlg)

    def export_saved(_):
        rows = list(reversed(engine.saved(limit=100000)))                  # oldest first
        if not rows:
            snack("Nothing to export yet.", ORANGE)
            return
        with_storage(lambda: ask_export_name(rows, "bin_atlas_saved"))     # permission check, then the name modal

    def clear_history(_):
        def do():
            engine.clear_history()
            refresh_saved()
            snack("History cleared (saved BINs kept).", GREEN)
        confirm("Delete History \u26A0\uFE0F", "All lookup history will be removed. Your saved BINs are kept.",
                "DELETE", "CANCEL", do)

    saved_q.on_change = refresh_saved
    # The two action buttons are pinned under the list (always visible above the tab bar);
    # only the lists scroll.
    saved_view = ft.Column([
        ft.Column([
            app_header("Saved", "Your saved numbers with notes, and history"),
            card(saved_q), saved_title, saved_list, hist_title, hist_list,
        ], spacing=12, scroll=ft.ScrollMode.AUTO, expand=True),
        ft.Container(padding=ft.padding.only(top=8), content=ft.Row([
            button("Export TXT", export_saved, icon=ICONS.DOWNLOAD, pad=10, size=13),
            button("Clear history", clear_history, icon=ICONS.DELETE_OUTLINE, pad=10, size=13)], spacing=10)),
    ], spacing=0, expand=True)

    # ======================================================== NAVIGATION
    def show(idx):
        close_dropdowns()
        nav_state["detail_back"] = None
        nav.selected_index = idx
        if idx == 0:
            body.content = lookup_view
        elif idx == 1:
            body.content = search_view
            refresh_db_card()
        elif idx == 2:
            body.content = finder_view
            f_hint.visible = engine.count() < 5000
        elif idx == 3:
            body.content = luhn_view
            if not luhn_out.controls:
                run_luhn()
        else:
            body.content = saved_view
            refresh_saved()
        page.update()

    def exit_app():
        try:
            if len(page.views) > 1:
                page.views.pop()                      # screen goes dark, then the process ends
            page.update()
        except Exception:
            pass
        timer = threading.Timer(0.25, hard_exit)
        timer.daemon = True
        timer.start()

    def on_back(e=None):
        """Android back button. An open dropdown closes first; a sub-screen (BIN details) goes back one
        step; on a main tab the first press shows a hint and a second press within EXIT_WINDOW exits."""
        try:
            if close_dropdowns():                  # an open dropdown closes first
                page.update()
                return
            if nav_state["detail_back"] is not None:
                show(nav_state["detail_back"])
                return
            now = time.monotonic()
            if now - nav_state["last_back"] <= EXIT_WINDOW:
                exit_app()
                return
            nav_state["last_back"] = now
            snack("Press back again to exit", CYAN, duration=int(EXIT_WINDOW * 1000))
        except Exception:
            pass

    def nav_dest(icon, label):
        try:                                           # smaller icon; falls back to the plain form if unsupported
            return ft.NavigationBarDestination(icon_content=ft.Icon(icon, size=20), label=label)
        except TypeError:
            return ft.NavigationBarDestination(icon=icon, label=label)

    nav = ft.NavigationBar(
        bgcolor=CARD_BG, indicator_color=BORDER, selected_index=0,
        on_change=lambda e: show(e.control.selected_index),
        destinations=[nav_dest(ICONS.SEARCH, "Lookup"), nav_dest(ICONS.ACCOUNT_BALANCE, "Banks"),
                      nav_dest(ICONS.EXPLORE, "Finder"), nav_dest(ICONS.SCHOOL, "Learn"),
                      nav_dest(ICONS.BOOKMARK, "Saved")])
    try:
        nav.height = 58                                # slimmer bar (default is 80)
    except Exception:
        pass
    body.content = lookup_view
    def outside_tap(e=None):
        if close_dropdowns():
            page.update()
    tap_layer = ft.GestureDetector(content=body, on_tap=outside_tap, expand=True)
    try:
        tap_layer.hit_test_behavior = ft.HitTestBehavior.TRANSLUCENT   # empty space counts as "outside" too
    except Exception:
        pass
    view.controls = [ft.SafeArea(tap_layer, expand=True)]   # replaces the splash in the same view
    view.navigation_bar = nav
    page.on_view_pop = on_back
    page.update()
    engine.prewarm()          # open provider connections in the background: faster first lookup
    threading.Thread(target=engine.export_folder, daemon=True).start()   # creates "BIN ATLAS" if allowed
    if engine.get_setting("storage_prompt_done") != "1":      # first launch after install / clearing storage
        engine.set_setting("storage_prompt_done", "1")
        if not storage_granted():
            ask_storage()


def main(page: ft.Page):
    page.title = "BIN Atlas"
    page.bgcolor = BG
    page.padding = 0
    page.theme_mode = ft.ThemeMode.DARK
    # Two views: the page's own (hidden, dark) base view plus the app view. With a single view
    # Android's back button closes the app at once; with two, Flet reports it (on_view_pop) and the
    # app can go back one step or ask for a double press.
    top = ft.View(route="/app", bgcolor=BG, padding=0, controls=[splash()])
    page.views.append(top)
    page.update()                         # dark logo + loading bar from the first Python frame
    try:
        from engine import BinEngine      # heavy imports (requests, sqlite) run while the splash shows
        engine = BinEngine()              # opens/migrates the database
        build_app(page, engine, top)
    except Exception:                     # show the error on screen instead of freezing on the splash
        top.controls = [ft.SafeArea(ft.Column([
            ft.Text("BIN Atlas could not start", size=18, color=RED, weight=ft.FontWeight.BOLD),
            ft.Text(traceback.format_exc(), size=11, color=WHITE, selectable=True)],
            scroll=ft.ScrollMode.AUTO), expand=True)]
        page.update()


if __name__ == "__main__":
    ft.app(target=main)
